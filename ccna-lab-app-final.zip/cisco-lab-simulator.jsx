import { useState, useEffect, useRef, useCallback } from "react";
import { TOPO_IMAGES } from "./topoImages";

// ─── LAB DATA ────────────────────────────────────────────────────────────────
const LABS = [
  {
    id: 1, title: "Static Routes & OSPF", category: "Routing",
    source: "Q214s",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.10.13.1/24", status: "up" }, "Ethernet0/1": { ip: "10.10.12.1/25", status: "up" }, "Ethernet0/2": { ip: "10.10.12.129/25", status: "up" }, "Loopback0": { ip: "10.10.1.1/32", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/0": { ip: "10.10.31.2/24", status: "up" }, "Ethernet0/1": { ip: "10.10.12.2/25", status: "up" }, "Ethernet0/2": { ip: "10.10.12.130/25", status: "up" } } },
      { name: "R3", type: "router", hostname: "R3", interfaces: { "Ethernet0/0": { ip: "10.10.13.3/24", status: "up" }, "Ethernet0/1": { ip: "10.10.254.3/24", status: "up" } } }
    ],
    topology: `Internet (172.20.20.128/25)\n    |.254\n   R3 (E0/1)\n    |E0/0 .3\n    | 10.10.13.0/24\n    |E0/0 .1\n   R1 ──E0/1(.1)── 10.10.12.0/25 ──E0/1(.2)── R2\n    └──E0/2(.129)── 10.10.12.128/25 ──E0/2(.130)─┘\n                                         E0/0 .2\n                                    10.10.31.0/24\n                                         E0/0 .1\n                                         SW1\n                                    LAN: 192.168.0.0/24`,
    tasks: [
      { id: 1, text: "Configure reachability to the switch SW1 LAN subnet (192.168.0.0/24) in router R2", device: "R2", hint: "ip route 192.168.0.0 255.255.255.0 10.10.31.1" },
      { id: 2, text: "Configure default reachability to the Internet subnet (172.20.20.128/25) in router R1", device: "R1", hint: "ip route 0.0.0.0 0.0.0.0 10.10.13.3" },
      { id: 3, text: "Configure a single static route in R2 to reach the Internet subnet. Use both redundant links (ECMP). No default route allowed.", device: "R2", hint: "ip route 172.20.20.128 255.255.255.128 10.10.12.1\nip route 172.20.20.128 255.255.255.128 10.10.12.129" },
      { id: 4, text: "Configure static route on R1 toward SW1 LAN. Primary via E0/1, backup via E0/2 (floating route, minimal AD)", device: "R1", hint: "ip route 192.168.0.0 255.255.255.0 Ethernet0/1 10.10.12.2\nip route 192.168.0.0 255.255.255.0 Ethernet0/2 10.10.12.130 2" }
    ]
  },
  {
    id: 2, title: "NAT, NTP, DHCP & SSH", category: "IP Services",
    source: "QLab211-Sim1",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.1.1.1/24", status: "up" }, "Ethernet0/2": { ip: "10.1.2.1/24", status: "up" }, "Loopback0": { ip: "192.168.100.1/24", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/0": { ip: "10.1.1.2/24", status: "up" }, "Ethernet0/1": { ip: "10.1.3.1/24", status: "up" } } },
      { name: "R3", type: "router", hostname: "R3", interfaces: { "Ethernet0/1": { ip: "10.1.3.3/24", status: "up" }, "Ethernet0/2": { ip: "dhcp", status: "up" } } }
    ],
    topology: `R1 (Lo0: 192.168.100.1)\n  E0/0 ── 10.1.1.0/24 ── E0/0 R2 E0/1 ── 10.1.3.0/24 ── E0/1 R3\n  E0/2 ── 10.1.2.0/24 ── E0/2 R2`,
    tasks: [
      { id: 1, text: "Configure NAT on R2: Translate R3 source to R2 E0/0 IP using standard ACL named PUBNET. Ping R1 Lo0 from R3.", device: "R2", hint: "ip nat inside source list PUBNET interface Ethernet0/0 overload\nip access-list standard PUBNET\npermit 10.1.3.0 0.0.0.255\ninterface Ethernet0/1\nip nat inside\ninterface Ethernet0/0\nip nat outside" },
      { id: 2, text: "Configure R1 as NTP server, R2 as client using R1 E0/2 IP (10.1.2.1). Set clock to midnight May 1, 2018.", device: "R1", hint: "ntp master\nclock set 00:00:00 May 1 2018" },
      { id: 3, text: "Configure R1 DHCP server for 10.1.3.0/24, pool NETPOOL. Exclude 1-10. R3 E0/2 gets 10.1.3.11 via DHCP.", device: "R1", hint: "ip dhcp excluded-address 10.1.3.1 10.1.3.10\nip dhcp pool NETPOOL\nnetwork 10.1.3.0 255.255.255.0" },
      { id: 4, text: "Configure SSH from R1 to R3. User netadmin/N3t4ccess on R3, RSA 1024 bits. Exclude other remote protocols.", device: "R3", hint: "username netadmin password N3t4ccess\nline vty 0 4\ntransport input ssh\nlogin local\ncrypto key generate rsa\n1024" }
    ]
  },
  {
    id: 3, title: "VLANs & Access Ports", category: "Switching",
    source: "QLab211-Sim2",
    devices: [
      { name: "SW1", type: "switch", hostname: "SW1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW2", type: "switch", hostname: "SW2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `SW1 (E0/0) ──── VLAN 12 ──── (E0/0) SW2\n │E0/1                          │E0/1\n Phone+PC                       PC\n VLAN 12+34                   VLAN "Available"`,
    tasks: [
      { id: 1, text: "Configure VLAN 12 named Compute and VLAN 34 named Telephony where required", device: "SW1", hint: "vlan 12\nname Compute\nvlan 34\nname Telephony" },
      { id: 2, text: "Configure E0/1 on SW2 to use the existing VLAN named Available", device: "SW2", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan ?" },
      { id: 3, text: "Configure the connection between switches using access ports", device: "SW1", hint: "interface Ethernet0/0\nswitchport mode access\nswitchport access vlan 12" },
      { id: 4, text: "Configure E0/1 on SW1 using data and voice VLANs", device: "SW1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 12\nswitchport voice vlan 34" },
      { id: 5, text: "Configure E0/1 on SW2 to disable Cisco proprietary neighbor discovery (CDP)", device: "SW2", hint: "interface Ethernet0/1\nno cdp enable" }
    ]
  },
  {
    id: 4, title: "ACL, User Accounts & DHCP Snooping", category: "Security",
    source: "Q213",
    devices: [
      { name: "Gw1", type: "router", hostname: "Gw1", interfaces: { "Ethernet0/0": { ip: "10.10.10.1/24", status: "up" }, "Ethernet0/2": { ip: "209.165.201.1/30", status: "up" } } },
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } }
    ],
    topology: `Internet ── (E0/2) Gw1 (E0/0) ── Sw3 ── Sw1\n                                    │        │\n                                  HostC    HostA\n                                 VLAN10   VLAN10`,
    tasks: [
      { id: 1, text: "Configure local account on Gw1: username wheel, password lock3path, scrypt, exec mode, telnet on vty 0-4", device: "Gw1", hint: "username wheel algorithm-type scrypt secret lock3path\nline vty 0 4\nlogin local\ntransport input telnet" },
      { id: 2, text: "Configure NACL CORP_ACL on Gw1: Allow BOOTP and HTTPS, deny all with detailed logging", device: "Gw1", hint: "ip access-list extended CORP_ACL\npermit udp any any eq bootps\npermit udp any any eq bootpc\npermit tcp any any eq 443\ndeny ip any any log-input" },
      { id: 3, text: "Configure DHCP Snooping on Sw1 for VLAN 10: disable Option-82, enable MAC verify, trusted interfaces", device: "Sw1", hint: "ip dhcp snooping\nip dhcp snooping vlan 10\nno ip dhcp snooping information option\nip dhcp snooping verify mac-address\ninterface Ethernet0/2\nip dhcp snooping trust" }
    ]
  },
  {
    id: 5, title: "ACL, User Accounts & DHCP Snooping (v2)", category: "Security",
    source: "Q214",
    devices: [
      { name: "Gw1", type: "router", hostname: "Gw1", interfaces: { "Ethernet0/0": { ip: "10.10.10.1/24", status: "up" }, "Ethernet0/2": { ip: "209.165.201.1/30", status: "up" } } },
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } }
    ],
    topology: `Internet ── (E0/2) Gw1 (E0/0) ── Sw3 ── Sw1\n                                  VLAN 10/20`,
    tasks: [
      { id: 1, text: "Configure local account on Gw1: username wheel, password lock3path, scrypt, exec mode, telnet vty 0-4", device: "Gw1", hint: "username wheel algorithm-type scrypt secret lock3path\nline vty 0 4\nlogin local\ntransport input telnet" },
      { id: 2, text: "Configure NACL CORP_ACL: Allow BOOTP+HTTPS, deny all with log-input", device: "Gw1", hint: "ip access-list extended CORP_ACL\npermit udp any any eq bootps\npermit udp any any eq bootpc\npermit tcp any any eq 443\ndeny ip any any log-input" },
      { id: 3, text: "Configure DHCP Snooping on Sw1 for VLAN 10", device: "Sw1", hint: "ip dhcp snooping\nip dhcp snooping vlan 10\nno ip dhcp snooping information option\nip dhcp snooping verify mac-address" }
    ]
  },
  {
    id: 6, title: "OSPF Configuration", category: "Routing",
    source: "Q227",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "GigabitEthernet0/0": { ip: "192.168.2.8/24", status: "up" }, "GigabitEthernet0/1": { ip: "10.10.13.1/24", status: "up" }, "Loopback1": { ip: "1.1.1.1/32", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "GigabitEthernet0/0": { ip: "192.168.2.1/24", status: "up" }, "Loopback0": { ip: "2.2.2.1/32", status: "up" }, "Loopback1": { ip: "2.2.2.2/32", status: "up" } } },
      { name: "R3", type: "router", hostname: "R3", interfaces: { "GigabitEthernet0/0": { ip: "192.168.2.6/24", status: "up" }, "GigabitEthernet0/1": { ip: "10.10.13.3/24", status: "up" }, "Loopback1": { ip: "3.3.3.3/32", status: "up" } } }
    ],
    topology: `       R2 (192.168.2.1, Lo: 2.2.2.1)\n       │G0/0\n       │ 192.168.2.0/24\n  R1 ──┤── R3\n G0/0  │  G0/0\n .8    │  .6\n       │\n R1 ──G0/1── 10.10.13.0/24 ──G0/1── R3`,
    tasks: [
      { id: 1, text: "Configure R1 Router ID using shared link IP (192.168.2.8), R2 Router ID (192.168.2.1)", device: "R1", hint: "router ospf 1\nrouter-id 192.168.2.8" },
      { id: 2, text: "Configure R2 OSPF priority to max (255) facing R1/R3. R2 must become DR.", device: "R2", hint: "interface GigabitEthernet0/0\nip ospf priority 255" },
      { id: 3, text: "Advertise Loopback1 networks on all routers using host wildcard mask", device: "R1", hint: "router ospf 1\nnetwork 1.1.1.1 0.0.0.0 area 0" },
      { id: 4, text: "Configure R1-R3 link to disable adding other OSPF routers (passive)", device: "R1", hint: "router ospf 1\npassive-interface GigabitEthernet0/1" }
    ]
  },
  {
    id: 7, title: "Static Routes to ISP & LAN", category: "Routing",
    source: "Q244",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.0.1.1/30", status: "up" }, "Ethernet0/1": { ip: "10.0.1.5/30", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/0": { ip: "10.0.1.2/30", status: "up" }, "Ethernet0/1": { ip: "10.0.2.1/30", status: "up" } } }
    ],
    topology: `ISP ── R1 ── R2 ── R3 ── R4(LAN: 10.0.41.0/24)\n            └── R3 (alternate path)`,
    tasks: [
      { id: 1, text: "Configure a default route on R2 to the ISP (via R1)", device: "R2", hint: "ip route 0.0.0.0 0.0.0.0 10.0.1.1" },
      { id: 2, text: "Configure a default route on R1 to the ISP", device: "R1", hint: "ip route 0.0.0.0 0.0.0.0 <ISP-next-hop>" },
      { id: 3, text: "Configure R2 with a route to Server 10.0.41.10", device: "R2", hint: "ip route 10.0.41.0 255.255.255.0 10.0.2.2" },
      { id: 4, text: "Configure R1 with a route to LAN preferring R3 as primary path", device: "R1", hint: "ip route 10.0.41.0 255.255.255.0 <R3-next-hop>" }
    ]
  },
  {
    id: 8, title: "VLANs, Access Ports & LLDP/CDP", category: "Switching",
    source: "Q252-Sim1",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } }
    ],
    topology: `R1──SW-1(E0/0)────(E0/0)SW-2──R2\n     │E0/1              │E0/1\n     PC1(VLAN15)        PC2(VLAN66)\n     E0/2────────────E0/2`,
    tasks: [
      { id: 1, text: "Configure SW-1 with VLAN 15 labeled exactly as OPS", device: "SW-1", hint: "vlan 15\nname OPS" },
      { id: 2, text: "Configure SW-2 with VLAN 66 labeled exactly as ENGINEERING", device: "SW-2", hint: "vlan 66\nname ENGINEERING" },
      { id: 3, text: "Configure the switch port connecting to PC1 (E0/1 on SW-1)", device: "SW-1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 15\nno shutdown" },
      { id: 4, text: "Configure the switch port connecting to PC2 (E0/1 on SW-2)", device: "SW-2", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 66\nno shutdown" },
      { id: 5, text: "Configure E0/2 for LLDP (vendor-neutral) and E0/0 for CDP (Cisco proprietary)", device: "SW-1", hint: "lldp run\ninterface Ethernet0/2\nlldp transmit\nlldp receive\ninterface Ethernet0/0\ncdp enable" }
    ]
  },
  {
    id: 9, title: "VLANs, Access & LLDP (v2)", category: "Switching",
    source: "Q252-Sim2",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `R1──SW-1────SW-2──R1\n     │E0/1    │E0/1\n     PC1      PC2\n   VLAN35   VLAN39`,
    tasks: [
      { id: 1, text: "Configure SW-1 with VLAN 35 labeled SALES", device: "SW-1", hint: "vlan 35\nname SALES" },
      { id: 2, text: "Configure SW-2 with VLAN 39 labeled MARKETING", device: "SW-2", hint: "vlan 39\nname MARKETING" },
      { id: 3, text: "Configure switch port connecting to PC1", device: "SW-1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 35" },
      { id: 4, text: "Configure switch port connecting to PC2", device: "SW-2", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 39" },
      { id: 5, text: "Enable LLDP globally, disable on PC1 interface", device: "SW-1", hint: "lldp run\ninterface Ethernet0/1\nno lldp transmit\nno lldp receive" }
    ]
  },
  {
    id: 10, title: "802.1Q Trunking & LACP", category: "Switching",
    source: "Q254",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "SW-3", type: "switch", hostname: "SW-3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `SW-1(E0/0,E0/1)──────(E0/0,E0/1)SW-2\n  │E0/2                    │E0/2\n  └──────(E0/0)SW-3(E0/1)──┘`,
    tasks: [
      { id: 1, text: "Configure SW-1/SW-2 E0/0 and E0/1 for 802.1q trunking allowing all VLANs", device: "SW-1", hint: "interface Ethernet0/0\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\ninterface Ethernet0/1\nswitchport trunk encapsulation dot1q\nswitchport mode trunk" },
      { id: 2, text: "Configure native VLAN 35 on SW-1 E0/2, SW-2 E0/2, SW-3 E0/0 and E0/1", device: "SW-1", hint: "interface Ethernet0/2\nswitchport trunk native vlan 35" },
      { id: 3, text: "Configure LACP: SW-1 active, SW-2 passive on E0/0 and E0/1", device: "SW-1", hint: "interface Ethernet0/0\nchannel-group 12 mode active\ninterface Ethernet0/1\nchannel-group 12 mode active" }
    ]
  },
  {
    id: 11, title: "Trunking, Native VLAN & LACP (v2)", category: "Switching",
    source: "Q257",
    devices: [
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } },
      { name: "SW-3", type: "switch", hostname: "SW-3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } }
    ],
    topology: `SW-1(pre-configured)\n  │E0/0          │E0/0\n SW-2            SW-3\n  │E0/2,E0/3────E0/2,E0/3│\n  (Port-channel)`,
    tasks: [
      { id: 1, text: "Configure SW-2/SW-3 E0/0 for dot1q trunk, tag only VLAN 10", device: "SW-2", hint: "interface Ethernet0/0\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk allowed vlan 10" },
      { id: 2, text: "Configure SW-2/SW-3 E0/0 native VLAN 11 (untagged traffic)", device: "SW-2", hint: "interface Ethernet0/0\nswitchport trunk native vlan 11" },
      { id: 3, text: "Configure E0/2 and E0/3 as dot1q trunk allowing all VLANs", device: "SW-2", hint: "interface range Ethernet0/2 - 3\nswitchport trunk encapsulation dot1q\nswitchport mode trunk" },
      { id: 4, text: "Configure LACP: SW-2 passive, SW-3 active on E0/2-3", device: "SW-2", hint: "interface Ethernet0/2\nchannel-group 1 mode passive\ninterface Ethernet0/3\nchannel-group 1 mode passive" }
    ]
  },
  {
    id: 12, title: "Trunk Allowed VLANs & LACP", category: "Switching",
    source: "Q262",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "SW-3", type: "switch", hostname: "SW-3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-4", type: "switch", hostname: "SW-4", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `R1──(E0/0)SW-1(E0/1)──(E0/1)SW-2(E0/2)\n              │                    │\n           SW-3(E0/0,E0/1)──(E0/0,E0/1)SW-4`,
    tasks: [
      { id: 1, text: "Configure SW-1 E0/0 to permit only VLANs 5 and 6", device: "SW-1", hint: "interface Ethernet0/0\nswitchport trunk allowed vlan 5,6" },
      { id: 2, text: "Configure SW-1 & SW-2 E0/1 native VLAN 77 (untagged)", device: "SW-1", hint: "interface Ethernet0/1\nswitchport trunk native vlan 77" },
      { id: 3, text: "Configure SW-2 E0/2 to permit only VLAN 6", device: "SW-2", hint: "interface Ethernet0/2\nswitchport trunk allowed vlan 6" },
      { id: 4, text: "Configure LACP: SW-3 active, SW-4 passive on E0/0 & E0/1", device: "SW-3", hint: "interface Ethernet0/0\nchannel-group 1 mode active\ninterface Ethernet0/1\nchannel-group 1 mode active" }
    ]
  },
  {
    id: 13, title: "ACL, Users & DHCP Snooping (v3)", category: "Security",
    source: "Q267",
    devices: [
      { name: "Sw103", type: "switch", hostname: "Sw103", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "172.16.0.1/16", status: "up" } } },
      { name: "Sw101", type: "switch", hostname: "Sw101", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `Internet ── R1 ── Sw103 ── Sw101\n                         VLAN 101`,
    tasks: [
      { id: 1, text: "Configure local account on Sw103: devnet/access8cli, SHA256, exec mode, telnet vty 0-4", device: "Sw103", hint: "username devnet algorithm-type sha256 secret access8cli\nline vty 0 4\nlogin local\ntransport input telnet" },
      { id: 2, text: "Modify NACL INTERNET_ACL on R1: Allow HTTPS from 172.16.0.0/16, Telnet for VLAN 101 only, deny all with log-input", device: "R1", hint: "ip access-list extended INTERNET_ACL\npermit tcp 172.16.0.0 0.0.255.255 any eq 443\npermit tcp <VLAN101-subnet> any eq 23\ndeny ip any any log-input" },
      { id: 3, text: "Configure DHCP Snooping on Sw101 for VLAN 101, disable Option-82, enable MAC verify", device: "Sw101", hint: "ip dhcp snooping\nip dhcp snooping vlan 101\nno ip dhcp snooping information option\nip dhcp snooping verify mac-address" }
    ]
  },
  {
    id: 14, title: "IPv4 & IPv6 Subnetting", category: "IP Addressing",
    source: "Q268-Sim1",
    devices: [
      { name: "Sw101", type: "switch", hostname: "Sw101", interfaces: { "Ethernet0/0": { status: "up" } } },
      { name: "Sw102", type: "switch", hostname: "Sw102", interfaces: { "Ethernet0/0": { status: "up" } } }
    ],
    topology: `Sw101 (E0/0) ─── (E0/0) Sw102\n\nSubnet 10.30.64.0/19 → 64 subnets\nSubnet 2001:db8::/56 → 64 subnets`,
    tasks: [
      { id: 1, text: "Subnet 10.30.64.0/19 for 64 sites. Use 2nd subnet: first usable IP → Sw101 E0/0, last usable → Sw102 E0/0", device: "Sw101", hint: "interface Ethernet0/0\nip address 10.30.66.1 255.255.254.0\n(2nd /25 subnet = 10.30.64.128, first=.129, last=.254)" },
      { id: 2, text: "Subnet 2001:db8::/56 for 64 sites. Use 2nd subnet with EUI-64 on both switches", device: "Sw101", hint: "interface Ethernet0/0\nipv6 address 2001:db8:0:1::/64 eui-64" }
    ]
  },
  {
    id: 15, title: "IPv6 Static & Floating Routes", category: "Routing",
    source: "Q268-Sim2",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "2001:db8:12::1/64", status: "up" }, "Ethernet0/1": { ip: "2001:db8:13::1/64", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/0": { ip: "2001:db8:12::2/64", status: "up" } } },
      { name: "R3", type: "router", hostname: "R3", interfaces: { "Ethernet0/1": { ip: "2001:db8:13::3/64", status: "up" } } }
    ],
    topology: `R1 ──E0/0── 2001:db8:12::/64 ──E0/0── R2\n │E0/1                              │\n 2001:db8:13::/64              2001:db8:41::/64\n │E0/1\n R3 ─── 2001:db8:41::/64`,
    tasks: [
      { id: 1, text: "Configure route on R1 to 2001:db8:41::/64 preferring R2", device: "R1", hint: "ipv6 route 2001:db8:41::/64 2001:db8:12::2" },
      { id: 2, text: "Configure floating route on R1 via R3 (higher AD) as backup", device: "R1", hint: "ipv6 route 2001:db8:41::/64 2001:db8:13::3 5" },
      { id: 3, text: "Verify ping and traceroute work", device: "R1", hint: "ping 2001:db8:41::1\ntraceroute 2001:db8:41::1" }
    ]
  },
  {
    id: 16, title: "Switch Ports, Voice VLAN & CDP/LLDP", category: "Switching",
    source: "Q269",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `R1 ── (E0/0) SW-1 (E0/0) ─── (E0/0) SW-2\n                │E0/1              │E0/1\n              Phone+PC              PC2\n              VLAN 10`,
    tasks: [
      { id: 1, text: "Configure SW-1 E0/1 for IP phone and PC traffic", device: "SW-1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 10\nswitchport voice vlan 20" },
      { id: 2, text: "Configure SW-2 E0/1 for PC2 traffic", device: "SW-2", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 10" },
      { id: 3, text: "Configure VLAN 10 named Engineering on SW-1", device: "SW-1", hint: "vlan 10\nname Engineering" },
      { id: 4, text: "Configure SW-1 to SW-2 link for vendor-neutral neighbor discovery (LLDP)", device: "SW-1", hint: "lldp run\ninterface Ethernet0/0\nlldp transmit\nlldp receive" },
      { id: 5, text: "Disable CDP on SW-1 link to R1", device: "SW-1", hint: "interface Ethernet0/0\nno cdp enable" }
    ]
  },
  {
    id: 17, title: "Voice & Data VLANs + LLDP", category: "Switching",
    source: "Q270-Sim1",
    devices: [
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } },
      { name: "Sw2", type: "switch", hostname: "Sw2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } }
    ],
    topology: `Sw1(E0/0)────(E0/0)Sw2\n │E0/1-3        │E0/1-3\n Phones+PCs    Phones+PCs`,
    tasks: [
      { id: 1, text: "Configure both VLANs on Sw1 and Sw2 with names from topology", device: "Sw1", hint: "vlan <data-vlan>\nname <data-name>\nvlan <voice-vlan>\nname <voice-name>" },
      { id: 2, text: "Configure E0/1, E0/2, E0/3 on both switches for voice and data VLANs", device: "Sw1", hint: "interface range Ethernet0/1 - 3\nswitchport mode access\nswitchport access vlan <data>\nswitchport voice vlan <voice>" },
      { id: 3, text: "Configure vendor-neutral neighbor discovery (LLDP) on E0/0 of both switches", device: "Sw1", hint: "lldp run\ninterface Ethernet0/0\nlldp transmit\nlldp receive" }
    ]
  },
  {
    id: 18, title: "Trunk Allowed VLANs & LACP (v2)", category: "Switching",
    source: "Q270-Sim2",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `SW-1(E0/0,E0/1)──(E0/0,E0/1)SW-2\n  │E0/2\n SW-3/SW-4 (preconfigured)`,
    tasks: [
      { id: 1, text: "Configure SW-1/SW-2 E0/0 and E0/1: 802.1q trunk, allow only VLANs 1,12,22", device: "SW-1", hint: "interface Ethernet0/0\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk allowed vlan 1,12,22" },
      { id: 2, text: "Configure SW-1 E0/2: 802.1q trunk, only VLANs 12 and 22", device: "SW-1", hint: "interface Ethernet0/2\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk allowed vlan 12,22" },
      { id: 3, text: "Configure LACP on SW-1/SW-2 E0/0,E0/1 — all ports must immediately negotiate", device: "SW-1", hint: "interface Ethernet0/0\nchannel-group 1 mode active\ninterface Ethernet0/1\nchannel-group 1 mode active" }
    ]
  },
  {
    id: 19, title: "NAT, DHCP, NTP & SSH (v2)", category: "IP Services",
    source: "Q272-Sim1",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.1.1.1/24", status: "up" }, "Loopback0": { ip: "192.168.100.1/24", status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/0": { ip: "10.1.1.2/24", status: "up" }, "Ethernet0/1": { ip: "10.1.3.1/24", status: "up" } } },
      { name: "R3", type: "router", hostname: "R3", interfaces: { "Ethernet0/1": { ip: "10.1.3.3/24", status: "up" }, "Ethernet0/2": { status: "up" } } }
    ],
    topology: `R1 (Lo0:192.168.100.1) ── R2 ── R3`,
    tasks: [
      { id: 1, text: "Configure dynamic 1-to-1 NAT on R2: ACL XLATE, pool test_pool (10.10.10.0/24)", device: "R2", hint: "ip nat pool test_pool 10.10.10.1 10.10.10.254 netmask 255.255.255.0\nip access-list standard XLATE\npermit any\nip nat inside source list XLATE pool test_pool" },
      { id: 2, text: "Configure R3 E0/2 to receive IP via DHCP", device: "R3", hint: "interface Ethernet0/2\nip address dhcp" },
      { id: 3, text: "Configure R1 as NTP server, R2 as client using 10.1.2.1", device: "R1", hint: "ntp master" },
      { id: 4, text: "Configure SSH on R3: user root, password s3cret, RSA, exclude other protocols", device: "R3", hint: "username root secret s3cret\nline vty 0 4\ntransport input ssh\nlogin local\ncrypto key generate rsa" }
    ]
  },
  {
    id: 20, title: "VLAN 99, Access Ports & CDP", category: "Switching",
    source: "Q272-Sim2",
    devices: [
      { name: "SW-1", type: "switch", hostname: "SW-1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-2", type: "switch", hostname: "SW-2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "SW-3", type: "switch", hostname: "SW-3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `SW-1(E0/1:PC1)──SW-2(E0/1:PC2)──SW-3(E0/1:PC3)\n    All VLAN 99 FINANCIAL`,
    tasks: [
      { id: 1, text: "Configure VLAN 99 on all three switches labeled FINANCIAL", device: "SW-1", hint: "vlan 99\nname FINANCIAL" },
      { id: 2, text: "Configure switch ports to PCs (E0/1) as access ports in VLAN 99", device: "SW-1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan 99" },
      { id: 3, text: "Re-enable CDP on SW-1 (it was disabled)", device: "SW-1", hint: "cdp run" },
      { id: 4, text: "Prevent PC1 from discovering SW-1 (disable CDP on E0/1)", device: "SW-1", hint: "interface Ethernet0/1\nno cdp enable" }
    ]
  },
  {
    id: 21, title: "User Account, ACL & Dynamic ARP Inspection", category: "Security",
    source: "Q274",
    devices: [
      { name: "Sw3", type: "switch", hostname: "Sw3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.0.0.1/24", status: "up" } } },
      { name: "Sw2", type: "switch", hostname: "Sw2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `ISP ── R1 ── Sw3 ── Sw2\n                    VLAN 5`,
    tasks: [
      { id: 1, text: "Configure local account on Sw3: tech12/load1key, md5, exec mode, telnet vty 0-4", device: "Sw3", hint: "username tech12 algorithm-type md5 secret load1key\nline vty 0 4\nlogin local\ntransport input telnet" },
      { id: 2, text: "Configure NACL ISP_ACL on R1: Restrict RFC1918 class A (10.0.0.0/8) and B (172.16.0.0/12), allow all else", device: "R1", hint: "ip access-list extended ISP_ACL\ndeny ip 10.0.0.0 0.255.255.255 any\ndeny ip 172.16.0.0 0.15.255.255 any\npermit ip any any" },
      { id: 3, text: "Configure DAI on Sw2: VLAN 5, validate dst-mac, src-mac, and IP", device: "Sw2", hint: "ip arp inspection vlan 5\nip arp inspection validate dst-mac src-mac ip" }
    ]
  },
  {
    id: 22, title: "IEEE Trunks & 802.3ad LACP", category: "Switching",
    source: "Q275",
    devices: [
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "Sw2", type: "switch", hostname: "Sw2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `Sw1(E0/0,E0/1)──(E0/0,E0/1)Sw2\n │                          │\nPC1(VLAN110)             PC2(VLAN110)`,
    tasks: [
      { id: 1, text: "Configure trunks on E0/0,E0/1 (dot1q). Native VLAN 99. Allow only VLAN 110 and native.", device: "Sw1", hint: "interface Ethernet0/0\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk native vlan 99\nswitchport trunk allowed vlan 99,110" },
      { id: 2, text: "Configure 802.3ad link aggregation: port-channel 20, both negotiate (LACP active)", device: "Sw1", hint: "interface Ethernet0/0\nchannel-group 20 mode active\ninterface Ethernet0/1\nchannel-group 20 mode active" }
    ]
  },
  {
    id: 23, title: "Voice/Data VLANs & LLDP (v2)", category: "Switching",
    source: "Q276-Sim1",
    devices: [
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } },
      { name: "Sw2", type: "switch", hostname: "Sw2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } }
    ],
    topology: `Sw1(E0/0)────(E0/0)Sw2\n │E0/1-3        │E0/1-3\n Phones+PCs    Phones+PCs`,
    tasks: [
      { id: 1, text: "Configure VLANs with naming as indicated in topology on both switches", device: "Sw1", hint: "vlan <id>\nname <name>" },
      { id: 2, text: "Assign VLANs to interfaces, set as non-trunking access ports", device: "Sw1", hint: "interface Ethernet0/1\nswitchport mode access\nswitchport access vlan <data>\nswitchport voice vlan <voice>" },
      { id: 3, text: "Configure L2 vendor-neutral discovery (LLDP) on E0/0 including native VLAN", device: "Sw1", hint: "lldp run\ninterface Ethernet0/0\nlldp transmit\nlldp receive" }
    ]
  },
  {
    id: 24, title: "OSPF without Network Statements", category: "Routing",
    source: "Q276-Sim2",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/0": { ip: "10.0.12.1/24", status: "up" }, "Ethernet0/1": { ip: "10.0.13.1/24", status: "up" } } }
    ],
    topology: `R2 ──(E0/0)── R1 ──(E0/1)── R3\n      10.0.12.0/24   10.0.13.0/24`,
    tasks: [
      { id: 1, text: "Configure OSPF process 33 with router-id using E0/1 IP", device: "R1", hint: "router ospf 33\nrouter-id 10.0.13.1" },
      { id: 2, text: "Establish OSPF adjacencies without network statements (use ip ospf on interfaces)", device: "R1", hint: "interface Ethernet0/0\nip ospf 33 area 0\ninterface Ethernet0/1\nip ospf 33 area 0" },
      { id: 3, text: "Configure R1 to always become DR (priority 255)", device: "R1", hint: "interface Ethernet0/0\nip ospf priority 255\ninterface Ethernet0/1\nip ospf priority 255" }
    ]
  },
  {
    id: 25, title: "IPv4 /28 & IPv6 /64 Configuration", category: "IP Addressing",
    source: "QLab212-Sim1",
    devices: [
      { name: "R1", type: "router", hostname: "R1", interfaces: { "Ethernet0/1": { status: "up" } } },
      { name: "R2", type: "router", hostname: "R2", interfaces: { "Ethernet0/1": { status: "up" } } }
    ],
    topology: `R1 (E0/1) ─── (E0/1) R2\nIPv4: 192.168.180.16/28 (2nd /28)\nIPv6: 2001:db8:acca::/64 (1st /64)`,
    tasks: [
      { id: 1, text: "Configure 2nd /28 from 192.168.180.0/24 (= 192.168.180.16/28). R1 = first usable (.17)", device: "R1", hint: "interface Ethernet0/1\nip address 192.168.180.17 255.255.255.240" },
      { id: 2, text: "R2 gets last usable IP of the /28 (.30)", device: "R2", hint: "interface Ethernet0/1\nip address 192.168.180.30 255.255.255.240" },
      { id: 3, text: "Configure IPv6 /64 from 2001:db8:acca::/48 (first /64 = 2001:db8:acca::/64)", device: "R1", hint: "interface Ethernet0/1\nipv6 address 2001:db8:acca::1/64" }
    ]
  },
  {
    id: 26, title: "VLANs, Trunks & VTP", category: "Switching",
    source: "QLab212-Sim2",
    devices: [
      { name: "Sw1", type: "switch", hostname: "Sw1", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" } } },
      { name: "Sw2", type: "switch", hostname: "Sw2", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/2": { status: "up" }, "Ethernet0/3": { status: "up" } } },
      { name: "Sw3", type: "switch", hostname: "Sw3", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" }, "Ethernet0/3": { status: "up" } } }
    ],
    topology: `PC1(VLAN202)──Sw1(E0/2)──(E0/2)Sw2(E0/3)──(E0/3)Sw3──PC3(VLAN303)\n                  │E0/0                │E0/1\n                 PC2(VLAN202)         PC4(VLAN303)`,
    tasks: [
      { id: 1, text: "Configure VLAN 202 (MARKETING) and VLAN 303 (FINANCE) on designated switches. Assign access ports.", device: "Sw1", hint: "vlan 202\nname MARKETING\ninterface Ethernet0/0\nswitchport mode access\nswitchport access vlan 202" },
      { id: 2, text: "Configure E0/2 on Sw1 and Sw2 as 802.1q trunks allowing only required VLANs", device: "Sw1", hint: "interface Ethernet0/2\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk allowed vlan 202,303" },
      { id: 3, text: "Configure E0/3 on Sw2 and Sw3 as 802.1q trunks allowing only required VLANs", device: "Sw2", hint: "interface Ethernet0/3\nswitchport trunk encapsulation dot1q\nswitchport mode trunk\nswitchport trunk allowed vlan 202,303" }
    ]
  },
  {
    id: 27, title: "User Account, ACL & Port Security", category: "Security",
    source: "QLab212-Sim3",
    devices: [
      { name: "Sw101", type: "switch", hostname: "Sw101", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } },
      { name: "Sw102", type: "switch", hostname: "Sw102", interfaces: { "Ethernet0/0": { status: "up" }, "Ethernet0/1": { status: "up" } } }
    ],
    topology: `PC1 ── Sw101 ── Sw102(E0/0) ── PC2\n       VLAN 100/200`,
    tasks: [
      { id: 1, text: "Configure local account on Sw101: support/max2learn, exec mode, telnet vty 0-4", device: "Sw101", hint: "username support secret max2learn\nline vty 0 4\nlogin local\ntransport input telnet" },
      { id: 2, text: "Configure NACL ENT_ACL on Sw101: Block PC2 ping to PC1, allow PC2 telnet to Sw101, deny other telnet from VLAN200, allow rest", device: "Sw101", hint: "ip access-list extended ENT_ACL\ndeny icmp host <PC2-IP> host <PC1-IP>\npermit tcp host <PC2-IP> host <Sw101-IP> eq 23\ndeny tcp any any eq 23\npermit ip any any" },
      { id: 3, text: "Configure port security on Sw102 E0/0: max 4 MACs, restrict mode, dynamic learning", device: "Sw102", hint: "interface Ethernet0/0\nswitchport port-security\nswitchport port-security maximum 4\nswitchport port-security violation restrict" }
    ]
  }
];




const CATEGORIES = [...new Set(LABS.map(l => l.category))];

// ─── CISCO IOS CLI EMULATOR v2 ─────────────────────────────────────────────
function createDeviceState(device) {
  return {
    hostname: device.hostname,
    type: device.type,
    mode: "user",
    currentInterface: null,
    currentLine: null,
    currentRouter: null,
    currentVlan: null,
    currentAcl: null,
    currentDhcpPool: null,
    // Structured running config
    globalCmds: [],
    interfaceCfg: {},
    lineCfg: {},
    routerCfg: {},
    vlanCfg: {},
    aclCfg: {},
    dhcpCfg: {},
    // State
    interfaces: JSON.parse(JSON.stringify(device.interfaces)),
    vlans: { 1: "default" },
    staticRoutes: [],
    staticRoutesV6: [],
    ospfConfig: {},
    users: [],
    natRules: [],
    dhcpExcluded: [],
    dhcpSnooping: { enabled: false, vlans: [], options: {} },
    daiConfig: { vlans: [], validate: [] },
    portSecurity: {},
    cdpGlobal: true,
    lldpGlobal: false,
    ntpConfig: {},
    sshConfigured: false,
    commandHistory: [],
    allCommands: [], // every command entered, with context
  };
}

function getPrompt(state) {
  const h = state.hostname;
  switch (state.mode) {
    case "user": return `${h}>`;
    case "privileged": return `${h}#`;
    case "config": return `${h}(config)#`;
    case "config-if": return `${h}(config-if)#`;
    case "config-subif": return `${h}(config-subif)#`;
    case "config-line": return `${h}(config-line)#`;
    case "config-router": return `${h}(config-router)#`;
    case "config-vlan": return `${h}(config-vlan)#`;
    case "config-acl": return `${h}(config-std-nacl)#`;
    case "config-ext-acl": return `${h}(config-ext-nacl)#`;
    case "config-dhcp": return `${h}(dhcp-config)#`;
    default: return `${h}#`;
  }
}

// Normalize interface name (handle abbreviations)
function normalizeInterface(input) {
  const map = {
    "e": "Ethernet", "et": "Ethernet", "eth": "Ethernet", "ethernet": "Ethernet",
    "f": "FastEthernet", "fa": "FastEthernet", "fas": "FastEthernet", "fastethernet": "FastEthernet",
    "g": "GigabitEthernet", "gi": "GigabitEthernet", "gig": "GigabitEthernet", "gigabitethernet": "GigabitEthernet",
    "l": "Loopback", "lo": "Loopback", "loop": "Loopback", "loopback": "Loopback",
    "p": "Port-channel", "po": "Port-channel", "port-channel": "Port-channel",
    "s": "Serial", "se": "Serial", "ser": "Serial", "serial": "Serial",
    "v": "Vlan", "vl": "Vlan", "vlan": "Vlan",
  };
  const m = input.match(/^([a-zA-Z-]+)\s*(.*)$/);
  if (!m) return input;
  const prefix = map[m[1].toLowerCase()] || m[1];
  return prefix + m[2].replace(/\s+/g, "");
}

// Parse an interface range like "Ethernet0/2 - 3" → ["Ethernet0/2", "Ethernet0/3"]
function parseInterfaceRange(input) {
  const parts = input.split(/\s*-\s*/);
  if (parts.length !== 2) return [normalizeInterface(input)];
  const base = normalizeInterface(parts[0].trim());
  const endNum = parts[1].trim();
  const match = base.match(/^(.+\/)(\d+)$/);
  if (!match) return [base];
  const prefix = match[1];
  const startNum = parseInt(match[2]);
  const end = parseInt(endNum);
  const result = [];
  for (let i = startNum; i <= end; i++) {
    result.push(`${prefix}${i}`);
  }
  return result;
}

function processCommand(input, state) {
  const rawCmd = input.trim();
  if (!rawCmd) return { output: "", state };

  state = { ...state };
  state.commandHistory = [...state.commandHistory, rawCmd];

  const cmd = rawCmd;
  const lc = cmd.toLowerCase();
  const parts = lc.split(/\s+/);
  const first = parts[0];

  // Record command with context for verification
  const cmdRecord = {
    raw: rawCmd,
    lower: lc,
    mode: state.mode,
    device: state.hostname,
    context: state.currentInterface || state.currentLine || state.currentRouter || state.currentVlan || state.currentAcl || state.currentDhcpPool || null,
  };
  state.allCommands = [...state.allCommands, cmdRecord];

  // Universal: ?
  if (rawCmd === "?") return { output: getHelp(state), state };

  // do command (from config modes, run privileged commands)
  if (first === "do" && state.mode.startsWith("config")) {
    const subCmd = rawCmd.substring(3).trim();
    const savedMode = state.mode;
    const savedCtx = { currentInterface: state.currentInterface, currentLine: state.currentLine, currentRouter: state.currentRouter, currentVlan: state.currentVlan, currentAcl: state.currentAcl, currentDhcpPool: state.currentDhcpPool };
    state.mode = "privileged";
    const result = processCommand(subCmd, state);
    result.state.mode = savedMode;
    Object.assign(result.state, savedCtx);
    return result;
  }

  // exit / end
  if (first === "exit" || first === "end") {
    if (first === "end") {
      return { output: "", state: { ...state, mode: state.mode === "user" ? "user" : "privileged", currentInterface: null, currentLine: null, currentRouter: null, currentVlan: null, currentAcl: null, currentDhcpPool: null } };
    }
    const modeUp = {
      "config-if": "config", "config-subif": "config", "config-line": "config",
      "config-router": "config", "config-vlan": "config", "config-acl": "config",
      "config-ext-acl": "config", "config-dhcp": "config",
      "config": "privileged", "privileged": "user",
    };
    const newMode = modeUp[state.mode] || state.mode;
    return { output: "", state: { ...state, mode: newMode, currentInterface: null, currentLine: null, currentRouter: null, currentVlan: null, currentAcl: null, currentDhcpPool: null } };
  }

  // ─── USER EXEC ────
  if (state.mode === "user") {
    if (first === "enable" || first === "en") return { output: "", state: { ...state, mode: "privileged" } };
    if (first === "ping") return doPing(parts, state);
    if (first === "traceroute" || first === "trace") return doTraceroute(parts, state);
    if (first === "show" || first === "sh") return processShow(parts, state);
    return { output: `% Unknown command or computer name, or unable to find computer address`, state };
  }

  // ─── PRIVILEGED EXEC ────
  if (state.mode === "privileged") {
    if (first === "configure" || first === "conf") {
      return { output: "Enter configuration commands, one per line. End with CNTL/Z.", state: { ...state, mode: "config" } };
    }
    if (first === "show" || first === "sh") return processShow(parts, state);
    if (first === "ping") return doPing(parts, state);
    if (first === "traceroute" || first === "trace") return doTraceroute(parts, state);
    if (first === "ssh") {
      const target = parts.slice(1).join(" ");
      return { output: `Password: \n\n[Connection to ${target} opened]\n${state.hostname}>`, state };
    }
    if (first === "copy") return { output: `[OK]\n${parts.slice(1).join(" ")} copied`, state };
    if (first === "write" || (first === "wr")) return { output: "Building configuration...\n[OK]", state };
    if (first === "clear") return { output: "", state };
    if (first === "terminal") return { output: "", state };
    if (first === "clock" && parts[1] === "set") {
      return { output: "", state };
    }
    if (first === "crypto" && parts[1] === "key") {
      state.sshConfigured = true;
      const bits = parts.find(p => /^\d{3,4}$/.test(p)) || "1024";
      return {
        output: `The name for the keys will be: ${state.hostname}.lab.local\nChoose the size of the key modulus in the range of 360 to 4096 for your\n  General Purpose Keys. Choosing a key modulus greater than 512 may take\n  a few minutes.\n\nHow many bits in the modulus [512]: ${bits}\n% Generating ${bits} bit RSA keys, keys will be non-exportable...\n[OK] (elapsed time was 1 seconds)`,
        state
      };
    }
    if (first === "undebug" || first === "debug") return { output: first === "debug" ? "Debugging enabled" : "All possible debugging has been turned off", state };
    if (first === "reload") return { output: "Proceed with reload? [confirm]\n\nSystem Bootstrap, Version 15.1(4)M4\n...\nSystem restarted", state };
    return { output: `% Unknown command '${first}'. Type '?' for help.`, state };
  }

  // ─── GLOBAL CONFIG ────
  if (state.mode === "config") {
    // Interface
    if (first === "interface" || first === "int") {
      const rest = rawCmd.replace(/^(interface|int)\s+/i, "");
      // Check for range
      if (rest.toLowerCase().startsWith("range ")) {
        const rangeStr = rest.replace(/^range\s+/i, "");
        const interfaces = parseInterfaceRange(rangeStr);
        const ifName = interfaces[0]; // work with first, store all
        if (!state.interfaceCfg[ifName]) state.interfaceCfg[ifName] = [];
        return { output: "", state: { ...state, mode: "config-if", currentInterface: ifName, _rangeInterfaces: interfaces } };
      }
      const ifName = normalizeInterface(rest);
      if (!state.interfaceCfg[ifName]) state.interfaceCfg[ifName] = [];
      return { output: "", state: { ...state, mode: "config-if", currentInterface: ifName } };
    }
    // Line
    if (first === "line") {
      const lineName = parts.slice(1).join(" ");
      if (!state.lineCfg[lineName]) state.lineCfg[lineName] = [];
      return { output: "", state: { ...state, mode: "config-line", currentLine: lineName } };
    }
    // Router
    if (first === "router") {
      const routerName = parts.slice(1).join(" ");
      if (!state.routerCfg[routerName]) state.routerCfg[routerName] = [];
      return { output: "", state: { ...state, mode: "config-router", currentRouter: routerName } };
    }
    // VLAN
    if (first === "vlan") {
      const vid = parts[1];
      return { output: "", state: { ...state, mode: "config-vlan", currentVlan: vid, vlans: { ...state.vlans, [vid]: state.vlans[vid] || "" } } };
    }
    // Named ACL
    if (first === "ip" && parts[1] === "access-list") {
      const isExtended = parts[2] === "extended";
      const isStandard = parts[2] === "standard";
      const aclName = isExtended ? parts.slice(3).join(" ") : isStandard ? parts.slice(3).join(" ") : parts.slice(2).join(" ");
      if (!state.aclCfg[aclName]) state.aclCfg[aclName] = [];
      return { output: "", state: { ...state, mode: isExtended ? "config-ext-acl" : "config-acl", currentAcl: aclName } };
    }
    // DHCP pool
    if (first === "ip" && parts[1] === "dhcp" && parts[2] === "pool") {
      const poolName = parts.slice(3).join(" ");
      if (!state.dhcpCfg[poolName]) state.dhcpCfg[poolName] = [];
      return { output: "", state: { ...state, mode: "config-dhcp", currentDhcpPool: poolName } };
    }
    // DHCP excluded
    if (first === "ip" && parts[1] === "dhcp" && parts[2] === "excluded-address") {
      state.dhcpExcluded = [...state.dhcpExcluded, lc];
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // DHCP snooping
    if (first === "ip" && parts[1] === "dhcp" && parts[2] === "snooping") {
      if (parts.length === 3) {
        state.dhcpSnooping = { ...state.dhcpSnooping, enabled: true };
      } else if (parts[3] === "vlan") {
        state.dhcpSnooping = { ...state.dhcpSnooping, vlans: [...state.dhcpSnooping.vlans, parts[4]] };
      }
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    if (first === "no" && parts[1] === "ip" && parts[2] === "dhcp" && parts[3] === "snooping") {
      state.dhcpSnooping = { ...state.dhcpSnooping, options: { ...state.dhcpSnooping.options, [parts.slice(4).join(" ")]: false } };
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // DAI
    if (first === "ip" && parts[1] === "arp" && parts[2] === "inspection") {
      if (parts[3] === "vlan") {
        state.daiConfig = { ...state.daiConfig, vlans: [...state.daiConfig.vlans, parts[4]] };
      } else if (parts[3] === "validate") {
        state.daiConfig = { ...state.daiConfig, validate: parts.slice(4) };
      }
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Static route IPv4
    if (first === "ip" && parts[1] === "route") {
      state.staticRoutes = [...state.staticRoutes, lc];
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Static route IPv6
    if (first === "ipv6" && parts[1] === "route") {
      state.staticRoutesV6 = [...state.staticRoutesV6, lc];
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // NAT
    if (first === "ip" && parts[1] === "nat") {
      state.natRules = [...state.natRules, lc];
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Username
    if (first === "username") {
      const username = parts[1];
      state.users = [...state.users, { cmd: lc, username }];
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Hostname
    if (first === "hostname") {
      const newName = rawCmd.split(/\s+/)[1] || state.hostname;
      state.hostname = newName;
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Crypto key
    if (first === "crypto" && parts[1] === "key") {
      state.sshConfigured = true;
      const bits = parts.find(p => /^\d{3,4}$/.test(p)) || "1024";
      state.globalCmds = [...state.globalCmds, lc];
      return {
        output: `The name for the keys will be: ${state.hostname}.lab.local\n% Generating ${bits} bit RSA keys...\n[OK]`,
        state
      };
    }
    // NTP
    if (first === "ntp") {
      state.ntpConfig = { ...state.ntpConfig, [parts.slice(1).join(" ")]: true };
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // CDP
    if (first === "cdp" && parts[1] === "run") { state.cdpGlobal = true; state.globalCmds = [...state.globalCmds, lc]; return { output: "", state }; }
    if (first === "no" && parts[1] === "cdp" && parts[2] === "run") { state.cdpGlobal = false; state.globalCmds = [...state.globalCmds, lc]; return { output: "", state }; }
    // LLDP
    if (first === "lldp" && parts[1] === "run") { state.lldpGlobal = true; state.globalCmds = [...state.globalCmds, lc]; return { output: "", state }; }
    if (first === "no" && parts[1] === "lldp") { state.lldpGlobal = false; state.globalCmds = [...state.globalCmds, lc]; return { output: "", state }; }
    // ipv6 unicast-routing
    if (first === "ipv6") {
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // no command (generic)
    if (first === "no") {
      state.globalCmds = [...state.globalCmds, lc];
      return { output: "", state };
    }
    // Catch all config commands
    state.globalCmds = [...state.globalCmds, lc];
    return { output: "", state };
  }

  // ─── INTERFACE CONFIG ────
  if (state.mode === "config-if" || state.mode === "config-subif") {
    const iface = state.currentInterface;
    const rangeIfs = state._rangeInterfaces || [iface];

    // Apply to all interfaces in range
    const newIfCfg = { ...state.interfaceCfg };
    for (const ifn of rangeIfs) {
      if (!newIfCfg[ifn]) newIfCfg[ifn] = [];
      newIfCfg[ifn] = [...newIfCfg[ifn], lc];
    }

    // Track specific state changes
    if (first === "ip" && parts[1] === "address") {
      const addr = parts.slice(2).join(" ");
      const newIfs = { ...state.interfaces };
      for (const ifn of rangeIfs) {
        newIfs[ifn] = { ...newIfs[ifn], ip: addr, status: "up" };
      }
      return { output: "", state: { ...state, interfaces: newIfs, interfaceCfg: newIfCfg } };
    }
    if (first === "ipv6" && parts[1] === "address") {
      const addr = parts.slice(2).join(" ");
      const newIfs = { ...state.interfaces };
      for (const ifn of rangeIfs) {
        newIfs[ifn] = { ...newIfs[ifn], ipv6: addr, status: "up" };
      }
      return { output: "", state: { ...state, interfaces: newIfs, interfaceCfg: newIfCfg } };
    }
    if (first === "no" && parts[1] === "shutdown") {
      const newIfs = { ...state.interfaces };
      for (const ifn of rangeIfs) { newIfs[ifn] = { ...newIfs[ifn], status: "up" }; }
      return { output: "", state: { ...state, interfaces: newIfs, interfaceCfg: newIfCfg } };
    }
    if (first === "shutdown") {
      const newIfs = { ...state.interfaces };
      for (const ifn of rangeIfs) { newIfs[ifn] = { ...newIfs[ifn], status: "administratively down" }; }
      return { output: "", state: { ...state, interfaces: newIfs, interfaceCfg: newIfCfg } };
    }
    // Port security
    if (lc.includes("port-security")) {
      const newPS = { ...state.portSecurity };
      for (const ifn of rangeIfs) {
        if (!newPS[ifn]) newPS[ifn] = {};
        if (parts.includes("maximum")) newPS[ifn].max = parts[parts.indexOf("maximum") + 1];
        if (parts.includes("violation")) newPS[ifn].violation = parts[parts.indexOf("violation") + 1];
        if (lc === "switchport port-security") newPS[ifn].enabled = true;
      }
      return { output: "", state: { ...state, portSecurity: newPS, interfaceCfg: newIfCfg } };
    }
    // DHCP snooping trust on interface
    if (first === "ip" && parts[1] === "dhcp" && parts[2] === "snooping" && parts[3] === "trust") {
      state.dhcpSnooping = { ...state.dhcpSnooping, trusted: [...(state.dhcpSnooping.trusted || []), iface] };
      return { output: "", state: { ...state, interfaceCfg: newIfCfg } };
    }
    // Channel-group
    if (first === "channel-group") {
      return { output: `Creating a port-channel interface Port-channel${parts[1]}`, state: { ...state, interfaceCfg: newIfCfg } };
    }
    // Navigate to another interface
    if (first === "interface" || first === "int") {
      const rest = rawCmd.replace(/^(interface|int)\s+/i, "");
      const newIf = normalizeInterface(rest);
      if (!newIfCfg[newIf]) newIfCfg[newIf] = [];
      return { output: "", state: { ...state, mode: "config-if", currentInterface: newIf, interfaceCfg: newIfCfg, _rangeInterfaces: undefined } };
    }
    return { output: "", state: { ...state, interfaceCfg: newIfCfg } };
  }

  // ─── LINE CONFIG ────
  if (state.mode === "config-line") {
    const line = state.currentLine;
    const newLineCfg = { ...state.lineCfg };
    if (!newLineCfg[line]) newLineCfg[line] = [];
    newLineCfg[line] = [...newLineCfg[line], lc];
    return { output: "", state: { ...state, lineCfg: newLineCfg } };
  }

  // ─── ROUTER CONFIG ────
  if (state.mode === "config-router") {
    const router = state.currentRouter;
    const newRtrCfg = { ...state.routerCfg };
    if (!newRtrCfg[router]) newRtrCfg[router] = [];
    newRtrCfg[router] = [...newRtrCfg[router], lc];
    if (first === "router-id") {
      state.ospfConfig = { ...state.ospfConfig, routerId: parts[1] };
    }
    if (first === "network") {
      const nets = state.ospfConfig.networks || [];
      state.ospfConfig = { ...state.ospfConfig, networks: [...nets, lc] };
    }
    return { output: "", state: { ...state, routerCfg: newRtrCfg } };
  }

  // ─── VLAN CONFIG ────
  if (state.mode === "config-vlan") {
    if (first === "name") {
      const name = rawCmd.replace(/^name\s+/i, "");
      return { output: "", state: { ...state, vlans: { ...state.vlans, [state.currentVlan]: name }, vlanCfg: { ...state.vlanCfg, [state.currentVlan]: name } } };
    }
    return { output: "", state };
  }

  // ─── ACL CONFIG ────
  if (state.mode === "config-acl" || state.mode === "config-ext-acl") {
    const acl = state.currentAcl;
    const newAclCfg = { ...state.aclCfg };
    if (!newAclCfg[acl]) newAclCfg[acl] = [];
    newAclCfg[acl] = [...newAclCfg[acl], lc];
    return { output: "", state: { ...state, aclCfg: newAclCfg } };
  }

  // ─── DHCP POOL CONFIG ────
  if (state.mode === "config-dhcp") {
    const pool = state.currentDhcpPool;
    const newDhcpCfg = { ...state.dhcpCfg };
    if (!newDhcpCfg[pool]) newDhcpCfg[pool] = [];
    newDhcpCfg[pool] = [...newDhcpCfg[pool], lc];
    return { output: "", state: { ...state, dhcpCfg: newDhcpCfg } };
  }

  return { output: "", state };
}

function doPing(parts, state) {
  const target = parts[1] || "?";
  if (target === "?") return { output: "  WORD  Ping destination address or hostname", state };
  return {
    output: `Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to ${target}, timeout is 2 seconds:\n!!!!!\nSuccess rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms`,
    state
  };
}

function doTraceroute(parts, state) {
  const target = parts[1] || "?";
  if (target === "?") return { output: "  WORD  Trace route to destination address", state };
  return {
    output: `Type escape sequence to abort.\nTracing the route to ${target}\nVRF info: (vrf in name/id, vrf out name/id)\n  1 ${target} 4 msec 4 msec 4 msec`,
    state
  };
}

function processShow(parts, state) {
  const sub = parts.slice(1).join(" ");

  // show running-config (hierarchical)
  if (sub.startsWith("run") || sub.startsWith("startup")) {
    return { output: buildRunningConfig(state), state };
  }
  // show ip interface brief
  if (sub.startsWith("ip int") || sub.startsWith("ip interface")) {
    const lines = [
      "Interface                  IP-Address      OK? Method Status                Protocol",
    ];
    Object.entries(state.interfaces).forEach(([name, info]) => {
      const ip = info.ip && info.ip !== "dhcp" ? info.ip.split("/")[0] : (info.ip === "dhcp" ? "DHCP" : "unassigned");
      lines.push(`${name.padEnd(27)}${ip.padEnd(16)}YES manual ${info.status.padEnd(22)}${info.status === "up" ? "up" : "down"}`);
    });
    return { output: lines.join("\n"), state };
  }
  // show interfaces
  if (sub.startsWith("int") && !sub.startsWith("ip")) {
    const lines = [];
    Object.entries(state.interfaces).forEach(([name, info]) => {
      lines.push(`${name} is ${info.status}, line protocol is ${info.status}`);
      if (info.ip) lines.push(`  Internet address is ${info.ip}`);
      lines.push(`  MTU 1500 bytes, BW 10000 Kbit/sec, DLY 1000 usec`);
      lines.push(`     reliability 255/255, txload 1/255, rxload 1/255`);
      lines.push(`  Encapsulation ARPA, loopback not set`);
      lines.push(`  Last input 00:00:01, output 00:00:01, output hang never`);
    });
    return { output: lines.join("\n"), state };
  }
  // show vlan brief
  if (sub.startsWith("vlan")) {
    const lines = [
      "VLAN Name                             Status    Ports",
      "---- -------------------------------- --------- -------------------------------",
    ];
    Object.entries(state.vlans).forEach(([id, name]) => {
      const vname = name || ("VLAN" + id).padEnd(0);
      lines.push(`${id.toString().padEnd(5)}${vname.padEnd(33)}active`);
    });
    return { output: lines.join("\n"), state };
  }
  // show ip route
  if (sub.startsWith("ip route") || sub.startsWith("ip ro")) {
    const lines = [
      "Codes: L - local, C - connected, S - static, R - RIP, O - OSPF,",
      "       B - BGP, * - candidate default",
      "",
    ];
    // Connected routes from interfaces
    Object.entries(state.interfaces).forEach(([name, info]) => {
      if (info.ip && info.ip !== "dhcp" && info.status === "up") {
        const ip = info.ip.split("/")[0];
        const cidr = info.ip.split("/")[1] || "24";
        lines.push(`C    ${ip}/${cidr} is directly connected, ${name}`);
      }
    });
    // Static routes
    state.staticRoutes.forEach(r => {
      const p = r.replace(/^ip route\s+/, "");
      lines.push(`S    ${p}`);
    });
    if (state.staticRoutes.length === 0 && Object.keys(state.interfaces).length === 0) {
      lines.push("% No routes found");
    }
    return { output: lines.join("\n"), state };
  }
  // show ipv6 route
  if (sub.startsWith("ipv6 route") || sub.startsWith("ipv6 ro")) {
    const lines = ["IPv6 Routing Table", "Codes: C - Connected, L - Local, S - Static, O - OSPF", ""];
    state.staticRoutesV6.forEach(r => {
      lines.push(`S    ${r.replace(/^ipv6 route\s+/, "")}`);
    });
    return { output: lines.join("\n"), state };
  }
  // show ip ospf
  if (sub.startsWith("ip ospf")) {
    const rid = state.ospfConfig.routerId || "0.0.0.0";
    const nets = state.ospfConfig.networks || [];
    const lines = [
      `Routing Process "ospf" with ID ${rid}`,
      `  Number of areas: 1 (Area 0)`,
      `  Number of interfaces: ${nets.length}`,
      `  Reference bandwidth: 100 mbps`,
    ];
    return { output: lines.join("\n"), state };
  }
  // show ip nat translations
  if (sub.startsWith("ip nat")) {
    if (state.natRules.length === 0) return { output: "% No NAT translations active", state };
    const lines = ["Pro Inside global      Inside local       Outside local      Outside global"];
    lines.push("--- ---                ---                ---                ---");
    return { output: lines.join("\n"), state };
  }
  // show cdp
  if (sub.startsWith("cdp")) {
    return {
      output: `Global CDP information:\n  Sending CDP packets every 60 seconds\n  Sending a holdtime value of 180 seconds\n  Sending CDPv2 advertisements is enabled\n  CDP is ${state.cdpGlobal ? "enabled" : "disabled"}`,
      state
    };
  }
  // show lldp
  if (sub.startsWith("lldp")) {
    return {
      output: `Global LLDP Information:\n  Status: ${state.lldpGlobal ? "ACTIVE" : "DISABLED"}\n  LLDP advertisements are sent every 30 seconds\n  LLDP hold time advertised is 120 seconds`,
      state
    };
  }
  // show port-security
  if (sub.includes("port-security")) {
    const lines = ["Secure Port  MaxSecureAddr  CurrentAddr  SecurityViolation  Security Action"];
    Object.entries(state.portSecurity).forEach(([iface, cfg]) => {
      if (cfg.enabled) {
        lines.push(`${iface.padEnd(13)}${(cfg.max || "1").padEnd(15)}0${" ".repeat(12)}0${" ".repeat(18)}${cfg.violation || "Shutdown"}`);
      }
    });
    if (lines.length === 1) lines.push("% Port security not configured on any interface");
    return { output: lines.join("\n"), state };
  }
  // show ip dhcp snooping
  if (sub.includes("dhcp snooping") || sub.includes("dhcp snoop")) {
    const lines = [
      `DHCP Snooping is ${state.dhcpSnooping.enabled ? "enabled" : "disabled"}`,
      `DHCP Snooping is configured on following VLANs: ${state.dhcpSnooping.vlans.join(",")||"none"}`,
    ];
    return { output: lines.join("\n"), state };
  }
  // show ip arp inspection
  if (sub.includes("arp inspection")) {
    const lines = [
      `Dynamic ARP Inspection configured on VLANs: ${state.daiConfig.vlans.join(",")||"none"}`,
      `Validation: ${state.daiConfig.validate.join(" ") || "none"}`,
    ];
    return { output: lines.join("\n"), state };
  }
  // show ntp
  if (sub.startsWith("ntp")) {
    const entries = Object.keys(state.ntpConfig);
    if (entries.length === 0) return { output: "% NTP is not configured", state };
    return { output: `NTP Configuration:\n  ${entries.join("\n  ")}`, state };
  }
  // show ip access-lists
  if (sub.includes("access-list") || sub.includes("access-lists")) {
    const lines = [];
    Object.entries(state.aclCfg).forEach(([name, entries]) => {
      lines.push(`IP access list ${name}`);
      entries.forEach((e, i) => lines.push(`  ${(i+1)*10} ${e}`));
    });
    if (lines.length === 0) lines.push("% No access lists configured");
    return { output: lines.join("\n"), state };
  }
  // show etherchannel / port-channel
  if (sub.includes("etherchannel") || sub.includes("port-channel")) {
    return { output: "Flags:  D - down  P - bundled in port-channel\n        U - in use\n\nGroup  Port-channel  Protocol    Ports\n------+-------------+-----------+-------", state };
  }
  // show ip dhcp pool
  if (sub.includes("dhcp pool")) {
    const lines = [];
    Object.entries(state.dhcpCfg).forEach(([name, entries]) => {
      lines.push(`Pool ${name}:`);
      entries.forEach(e => lines.push(`  ${e}`));
    });
    if (lines.length === 0) lines.push("% No DHCP pools configured");
    return { output: lines.join("\n"), state };
  }
  // show version
  if (sub.startsWith("ver")) {
    return {
      output: `Cisco IOS Software, Version 15.9(3)M7\nCopyright (c) by Cisco Systems, Inc.\n\nROM: System Bootstrap, Version 15.1(4)M4\n\n${state.hostname} uptime is 0 minutes\nSystem image file is "flash:c2900-universalk9-mz.SPA.159-3.M7.bin"\n\nCisco CISCO2901/K9 (revision 1.0) with 491520K/32768K bytes of memory.\nProcessor board ID FJC2139F0BK\n2 Gigabit Ethernet interfaces\nDRAM configuration is 64 bits wide with parity disabled.\n256K bytes of non-volatile configuration memory.\n255744K bytes of ATA System CompactFlash 0 (Read/Write)`,
      state
    };
  }
  // show clock
  if (sub.startsWith("clock")) {
    return { output: `*12:00:00.000 UTC Sat Feb 21 2026`, state };
  }
  return { output: `% Invalid input detected at '^' marker.\n\n  show ${sub}\n       ^`, state };
}

function buildRunningConfig(state) {
  const lines = [
    "Building configuration...",
    "",
    "Current configuration : " + state.hostname,
    "!",
    "version 15.9",
    "service timestamps debug datetime msec",
    "service timestamps log datetime msec",
    "!",
    `hostname ${state.hostname}`,
    "!",
  ];
  // Users
  state.users.forEach(u => lines.push(u.cmd));
  if (state.users.length) lines.push("!");
  // Global commands (filtered for display)
  const displayGlobal = state.globalCmds.filter(c =>
    !c.startsWith("username") && !c.startsWith("cdp") && !c.startsWith("lldp") && !c.startsWith("ntp")
  );
  displayGlobal.forEach(c => lines.push(c));
  if (displayGlobal.length) lines.push("!");
  // LLDP/CDP
  if (state.lldpGlobal) lines.push("lldp run");
  if (!state.cdpGlobal) lines.push("no cdp run");
  // NTP
  Object.keys(state.ntpConfig).forEach(k => lines.push(`ntp ${k}`));
  // ACLs
  Object.entries(state.aclCfg).forEach(([name, entries]) => {
    lines.push(`ip access-list ${name}`);
    entries.forEach(e => lines.push(` ${e}`));
    lines.push("!");
  });
  // DHCP
  state.dhcpExcluded.forEach(c => lines.push(c));
  Object.entries(state.dhcpCfg).forEach(([name, entries]) => {
    lines.push(`ip dhcp pool ${name}`);
    entries.forEach(e => lines.push(` ${e}`));
    lines.push("!");
  });
  // Static routes
  state.staticRoutes.forEach(r => lines.push(r));
  state.staticRoutesV6.forEach(r => lines.push(r));
  // NAT
  state.natRules.forEach(r => lines.push(r));
  // VLANs
  Object.entries(state.vlanCfg).forEach(([id, name]) => {
    lines.push(`vlan ${id}`);
    if (name) lines.push(` name ${name}`);
    lines.push("!");
  });
  // Interfaces
  Object.entries(state.interfaceCfg).forEach(([iface, cmds]) => {
    if (cmds.length === 0) return;
    lines.push(`interface ${iface}`);
    cmds.forEach(c => lines.push(` ${c}`));
    lines.push("!");
  });
  // Lines
  Object.entries(state.lineCfg).forEach(([line, cmds]) => {
    if (cmds.length === 0) return;
    lines.push(`line ${line}`);
    cmds.forEach(c => lines.push(` ${c}`));
    lines.push("!");
  });
  // Router
  Object.entries(state.routerCfg).forEach(([router, cmds]) => {
    if (cmds.length === 0) return;
    lines.push(`router ${router}`);
    cmds.forEach(c => lines.push(` ${c}`));
    lines.push("!");
  });
  lines.push("!", "end");
  return lines.join("\n");
}

function getHelp(state) {
  const helps = {
    user: [
      ["enable", "Turn on privileged commands"],
      ["ping", "Send echo messages"],
      ["show", "Show running system information"],
      ["traceroute", "Trace route to destination"],
    ],
    privileged: [
      ["configure terminal", "Enter configuration mode"],
      ["copy", "Copy from one file to another"],
      ["clock set", "Set the time and date"],
      ["crypto key generate rsa", "Generate RSA keys for SSH"],
      ["debug", "Debugging functions"],
      ["ping", "Send echo messages"],
      ["reload", "Halt and perform a cold restart"],
      ["show", "Show running system information"],
      ["ssh", "Open a secure shell client connection"],
      ["terminal", "Set terminal line parameters"],
      ["traceroute", "Trace route to destination"],
      ["write memory", "Save running config to NVRAM"],
    ],
    config: [
      ["cdp run", "Enable CDP"],
      ["crypto key generate rsa", "Generate RSA keys"],
      ["hostname", "Set system's network name"],
      ["interface", "Select an interface to configure"],
      ["ip access-list", "Named access list"],
      ["ip arp inspection", "Dynamic ARP Inspection"],
      ["ip dhcp excluded-address", "Prevent DHCP from assigning certain addresses"],
      ["ip dhcp pool", "Configure DHCP address pool"],
      ["ip dhcp snooping", "DHCP Snooping"],
      ["ip nat", "NAT configuration commands"],
      ["ip route", "Establish static routes"],
      ["ipv6 route", "Establish IPv6 static routes"],
      ["line", "Configure a terminal line"],
      ["lldp run", "Enable LLDP"],
      ["no", "Negate a command or set its defaults"],
      ["ntp", "Configure NTP"],
      ["router", "Enable a routing process"],
      ["username", "Establish user name authentication"],
      ["vlan", "VLAN commands"],
    ],
    "config-if": [
      ["cdp enable", "Enable CDP on this interface"],
      ["channel-group", "Etherchannel/port bundling"],
      ["ip address", "Set the IP address of an interface"],
      ["ip dhcp snooping trust", "DHCP Snooping trust"],
      ["ip nat inside|outside", "NAT interface designation"],
      ["ip ospf", "OSPF interface commands"],
      ["ipv6 address", "Set the IPv6 address"],
      ["lldp transmit|receive", "LLDP per-interface"],
      ["no", "Negate a command"],
      ["shutdown", "Shutdown the selected interface"],
      ["switchport access vlan", "Set access mode VLAN"],
      ["switchport mode", "Set interface trunking mode"],
      ["switchport port-security", "Port security"],
      ["switchport trunk", "Trunk configuration"],
      ["switchport voice vlan", "Set voice VLAN"],
    ],
    "config-line": [
      ["login local", "Enable login using local database"],
      ["password", "Set a line password"],
      ["transport input", "Define which protocols to use for incoming connections"],
    ],
    "config-router": [
      ["network", "Enable routing on an IP network"],
      ["passive-interface", "Suppress routing updates on an interface"],
      ["router-id", "Router ID for this OSPF process"],
    ],
    "config-vlan": [
      ["name", "ASCII name of the VLAN"],
    ],
    "config-acl": [
      ["deny", "Specify packets to reject"],
      ["permit", "Specify packets to forward"],
    ],
    "config-ext-acl": [
      ["deny", "Specify packets to reject"],
      ["permit", "Specify packets to forward"],
    ],
    "config-dhcp": [
      ["default-router", "Default routers"],
      ["dns-server", "DNS servers"],
      ["network", "Network number and mask"],
    ],
  };
  const entries = helps[state.mode] || [["?", "Show help"]];
  return entries.map(([cmd, desc]) => `  ${cmd.padEnd(28)} ${desc}`).join("\n");
}

// ─── TASK VERIFICATION ENGINE ───────────────────────────────────────────────
function normalizeForCheck(s) {
  return s.toLowerCase().replace(/\s+/g, " ").trim();
}

function checkTaskCompletion(task, deviceStates) {
  const deviceName = task.device;
  const ds = deviceStates[deviceName];
  if (!ds) return false;

  const hint = task.hint;
  // Parse hint into individual commands
  const hintLines = hint.split("\n").map(l => l.trim()).filter(l => l && !l.startsWith("(") && !l.startsWith("//"));

  // Get all commands entered on this device with context
  const allCmds = ds.allCommands.filter(c => c.device === deviceName);
  const allCmdLower = allCmds.map(c => c.lower);

  // Also build a flat list of all config commands (from structured config)
  const allConfigFlat = [
    ...ds.globalCmds,
    ...Object.values(ds.interfaceCfg).flat(),
    ...Object.values(ds.lineCfg).flat(),
    ...Object.values(ds.routerCfg).flat(),
    ...Object.values(ds.aclCfg).flat(),
    ...Object.values(ds.dhcpCfg).flat(),
  ];

  // For each hint line, check if a matching command was entered
  let matchCount = 0;
  for (const hintLine of hintLines) {
    const normalized = normalizeForCheck(hintLine);

    // Skip pure numeric lines (like RSA key size "1024")
    if (/^\d+$/.test(normalized)) { matchCount++; continue; }

    // Skip lines with placeholder syntax
    if (normalized.includes("<") && normalized.includes(">")) { matchCount++; continue; }
    if (normalized === "?") { matchCount++; continue; }

    // Extract key tokens from hint line
    const tokens = normalized.split(" ").filter(t => t.length > 0);

    // Check if any entered command matches this hint line
    const found = allCmdLower.some(enteredCmd => {
      return matchHintToCommand(normalized, enteredCmd);
    }) || allConfigFlat.some(cfgCmd => {
      return matchHintToCommand(normalized, cfgCmd);
    });

    if (found) matchCount++;
  }

  return matchCount >= hintLines.length;
}

function matchHintToCommand(hintNorm, cmdNorm) {
  // Exact match
  if (hintNorm === cmdNorm) return true;

  // Normalize both
  const h = hintNorm.replace(/\s+/g, " ").trim();
  const c = cmdNorm.replace(/\s+/g, " ").trim();

  if (h === c) return true;

  // Check if all significant tokens from hint exist in command
  const hTokens = h.split(" ");
  const cTokens = c.split(" ");

  // For short commands (1-3 tokens), require near-exact match
  if (hTokens.length <= 3) {
    // Allow interface name variations
    const hNormIf = h.replace(/ethernet/g, "ethernet").replace(/gigabitethernet/g, "gigabitethernet");
    const cNormIf = c.replace(/ethernet/g, "ethernet").replace(/gigabitethernet/g, "gigabitethernet");
    return hNormIf === cNormIf;
  }

  // For longer commands, check if all critical tokens match
  let matchedTokens = 0;
  for (const ht of hTokens) {
    if (cTokens.includes(ht)) matchedTokens++;
  }

  // Require 80%+ token match
  return matchedTokens >= Math.ceil(hTokens.length * 0.8);
}

// ─── THEME CONFIG ────────────────────────────────────────────────────────────
const THEMES = {
  dark: {
    bg: "#0a0e17", bgAlt: "#0d1117", card: "#111820",
    border: "#1e2a3a", borderAccent: "#1a8870",
    text: "#e0e6ed", textMuted: "#6b7b8d", textDim: "#8b9bb4",
    accent: "#00d4aa", accentAlt: "#0891b2",
    routerBg: "#1a3a2a", routerText: "#4ade80", routerBorder: "#2a5a3a",
    switchBg: "#1a2a3a", switchText: "#60a5fa", switchBorder: "#2a3a5a",
    warn: "#f59e0b", headerGrad: "linear-gradient(135deg, #0d1117 0%, #161b22 50%, #0d1117 100%)",
    catBg: "#0891b215", accentBg: "#00d4aa15",
    hintBg: "#0a0e17",
    successBg: "#052e16", successBorder: "#16a34a", successText: "#4ade80",
  },
  light: {
    bg: "#f3f4f6", bgAlt: "#ffffff", card: "#ffffff",
    border: "#d1d5db", borderAccent: "#10b981",
    text: "#1f2937", textMuted: "#6b7280", textDim: "#4b5563",
    accent: "#059669", accentAlt: "#0284c7",
    routerBg: "#dcfce7", routerText: "#15803d", routerBorder: "#86efac",
    switchBg: "#dbeafe", switchText: "#1d4ed8", switchBorder: "#93c5fd",
    warn: "#d97706", headerGrad: "linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 50%, #f0fdf4 100%)",
    catBg: "#0284c715", accentBg: "#05966915",
    hintBg: "#f9fafb",
    successBg: "#f0fdf4", successBorder: "#16a34a", successText: "#15803d",
  }
};

// ─── MAIN APP COMPONENT ──────────────────────────────────────────────────────
export default function CiscoLabSimulator() {
  const [selectedLab, setSelectedLab] = useState(null);
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [deviceStates, setDeviceStates] = useState({});
  const [terminalHistory, setTerminalHistory] = useState([]);
  const [currentInput, setCurrentInput] = useState("");
  const [cmdHistoryIdx, setCmdHistoryIdx] = useState(-1);
  const [showHint, setShowHint] = useState({});
  const [completedTasks, setCompletedTasks] = useState({});
  const [sidebarTab, setSidebarTab] = useState("tasks");
  const [filterCategory, setFilterCategory] = useState("All");
  const [showLabList, setShowLabList] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [toasts, setToasts] = useState([]);
  const [recentlyCompleted, setRecentlyCompleted] = useState({});
  const terminalRef = useRef(null);
  const inputRef = useRef(null);

  const T = darkMode ? THEMES.dark : THEMES.light;
  const lab = selectedLab ? LABS.find(l => l.id === selectedLab) : null;

  useEffect(() => {
    if (lab) {
      const states = {};
      lab.devices.forEach(d => { states[d.name] = createDeviceState(d); });
      setDeviceStates(states);
      setSelectedDevice(lab.devices[0]?.name);
      setTerminalHistory([{ type: "system", text: `\n  ═══════════════════════════════════════════════\n  Cisco IOS Simulator — Lab ${lab.id}: ${lab.title}\n  ═══════════════════════════════════════════════\n\n  Type 'enable' then 'configure terminal' to begin.\n  Type '?' for help. Use 'do <cmd>' from config mode.\n` }]);
      setShowHint({});
    }
  }, [selectedLab]);

  useEffect(() => { if (terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight; }, [terminalHistory]);
  useEffect(() => { if (inputRef.current) inputRef.current.focus(); }, [selectedDevice, terminalHistory]);

  const currentState = selectedDevice ? deviceStates[selectedDevice] : null;

  // ─── Auto-verify tasks after device state changes ───
  useEffect(() => {
    if (!lab || Object.keys(deviceStates).length === 0) return;
    lab.tasks.forEach(task => {
      const key = `${lab.id}-${task.id}`;
      if (completedTasks[key]) return; // already complete
      const passed = checkTaskCompletion(task, deviceStates);
      if (passed) {
        setCompletedTasks(prev => ({ ...prev, [key]: true }));
        setRecentlyCompleted(prev => ({ ...prev, [key]: true }));
        // Toast
        setToasts(prev => [...prev, { id: Date.now(), text: `✓ Task ${task.id} complete: ${task.text.substring(0, 50)}...`, taskKey: key }]);
        // Clear recent highlight after 3s
        setTimeout(() => setRecentlyCompleted(prev => { const n = { ...prev }; delete n[key]; return n; }), 3000);
      }
    });
  }, [deviceStates, lab]);

  // Remove toasts after 4s
  useEffect(() => {
    if (toasts.length === 0) return;
    const timer = setTimeout(() => setToasts(prev => prev.slice(1)), 4000);
    return () => clearTimeout(timer);
  }, [toasts]);

  const switchDevice = useCallback((deviceName) => {
    setSelectedDevice(deviceName);
    setTerminalHistory(prev => [...prev, { type: "system", text: `\n--- Switched to ${deviceName} console ---\n` }]);
    setCurrentInput("");
    setCmdHistoryIdx(-1);
  }, []);

  const handleCommand = useCallback(() => {
    if (!currentState || !currentInput.trim()) return;
    const prompt = getPrompt(currentState);
    const { output, state: newState } = processCommand(currentInput, JSON.parse(JSON.stringify(currentState)));
    setTerminalHistory(prev => [
      ...prev,
      { type: "input", text: `${prompt} ${currentInput}` },
      ...(output ? [{ type: "output", text: output }] : [])
    ]);
    setDeviceStates(prev => ({ ...prev, [selectedDevice]: newState }));
    setCurrentInput("");
    setCmdHistoryIdx(-1);
  }, [currentState, currentInput, selectedDevice]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === "Enter") { handleCommand(); }
    else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (currentState?.commandHistory.length > 0) {
        const newIdx = cmdHistoryIdx < currentState.commandHistory.length - 1 ? cmdHistoryIdx + 1 : cmdHistoryIdx;
        setCmdHistoryIdx(newIdx);
        setCurrentInput(currentState.commandHistory[currentState.commandHistory.length - 1 - newIdx] || "");
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (cmdHistoryIdx > 0) { setCmdHistoryIdx(cmdHistoryIdx - 1); setCurrentInput(currentState.commandHistory[currentState.commandHistory.length - cmdHistoryIdx] || ""); }
      else { setCmdHistoryIdx(-1); setCurrentInput(""); }
    } else if (e.key === "Tab") {
      e.preventDefault();
      const partial = currentInput.toLowerCase().trim();
      // Context-aware tab completion
      const isConfig = currentState?.mode?.startsWith("config");
      const isIf = currentState?.mode === "config-if";
      const allCompletions = [
        // universal
        { p: "en", c: "enable", modes: ["user"] },
        { p: "conf", c: "configure terminal", modes: ["privileged"] },
        { p: "sh r", c: "show running-config", modes: ["privileged", "user"] },
        { p: "sh ip int", c: "show ip interface brief", modes: ["privileged", "user"] },
        { p: "sh ip ro", c: "show ip route", modes: ["privileged", "user"] },
        { p: "sh vl", c: "show vlan brief", modes: ["privileged", "user"] },
        { p: "sh ip os", c: "show ip ospf", modes: ["privileged"] },
        { p: "sh cd", c: "show cdp", modes: ["privileged"] },
        { p: "sh ll", c: "show lldp", modes: ["privileged"] },
        { p: "sh ip ac", c: "show ip access-lists", modes: ["privileged"] },
        { p: "sh ip na", c: "show ip nat translations", modes: ["privileged"] },
        { p: "sh ver", c: "show version", modes: ["privileged"] },
        { p: "sh cl", c: "show clock", modes: ["privileged"] },
        { p: "sh po", c: "show port-security", modes: ["privileged"] },
        { p: "sh ip dh", c: "show ip dhcp snooping", modes: ["privileged"] },
        { p: "sh ip ar", c: "show ip arp inspection", modes: ["privileged"] },
        { p: "sh eth", c: "show etherchannel summary", modes: ["privileged"] },
        { p: "wr", c: "write memory", modes: ["privileged"] },
        { p: "pi", c: "ping ", modes: ["privileged", "user"] },
        { p: "tr", c: "traceroute ", modes: ["privileged", "user"] },
        // config
        { p: "int ", c: "interface ", modes: ["config"] },
        { p: "int e", c: "interface Ethernet", modes: ["config"] },
        { p: "int g", c: "interface GigabitEthernet", modes: ["config"] },
        { p: "int lo", c: "interface Loopback", modes: ["config"] },
        { p: "int ra", c: "interface range ", modes: ["config"] },
        { p: "ip ro", c: "ip route ", modes: ["config"] },
        { p: "ip ac", c: "ip access-list ", modes: ["config"] },
        { p: "ip na", c: "ip nat ", modes: ["config"] },
        { p: "ip dh", c: "ip dhcp ", modes: ["config"] },
        { p: "ipv6 ro", c: "ipv6 route ", modes: ["config"] },
        { p: "vl", c: "vlan ", modes: ["config"] },
        { p: "li", c: "line vty 0 4", modes: ["config"] },
        { p: "us", c: "username ", modes: ["config"] },
        { p: "ro", c: "router ospf ", modes: ["config"] },
        { p: "ll", c: "lldp run", modes: ["config"] },
        { p: "cd", c: "cdp run", modes: ["config"] },
        { p: "cr", c: "crypto key generate rsa", modes: ["config"] },
        { p: "nt", c: "ntp ", modes: ["config"] },
        { p: "ho", c: "hostname ", modes: ["config"] },
        { p: "no", c: "no ", modes: ["config", "config-if", "config-line", "config-router"] },
        // interface
        { p: "sw m", c: "switchport mode ", modes: ["config-if"] },
        { p: "sw ac", c: "switchport access vlan ", modes: ["config-if"] },
        { p: "sw vo", c: "switchport voice vlan ", modes: ["config-if"] },
        { p: "sw tr e", c: "switchport trunk encapsulation dot1q", modes: ["config-if"] },
        { p: "sw tr a", c: "switchport trunk allowed vlan ", modes: ["config-if"] },
        { p: "sw tr n", c: "switchport trunk native vlan ", modes: ["config-if"] },
        { p: "sw po", c: "switchport port-security", modes: ["config-if"] },
        { p: "ch", c: "channel-group ", modes: ["config-if"] },
        { p: "ip ad", c: "ip address ", modes: ["config-if"] },
        { p: "ip os", c: "ip ospf ", modes: ["config-if"] },
        { p: "ip na", c: "ip nat ", modes: ["config-if"] },
        { p: "ip dh", c: "ip dhcp snooping trust", modes: ["config-if"] },
        { p: "ipv6 ad", c: "ipv6 address ", modes: ["config-if"] },
        { p: "no sh", c: "no shutdown", modes: ["config-if"] },
        { p: "sh", c: "shutdown", modes: ["config-if"] },
        { p: "ll t", c: "lldp transmit", modes: ["config-if"] },
        { p: "ll r", c: "lldp receive", modes: ["config-if"] },
        { p: "no ll t", c: "no lldp transmit", modes: ["config-if"] },
        { p: "no ll r", c: "no lldp receive", modes: ["config-if"] },
        { p: "cd", c: "cdp enable", modes: ["config-if"] },
        { p: "no cd", c: "no cdp enable", modes: ["config-if"] },
        // line
        { p: "lo", c: "login local", modes: ["config-line"] },
        { p: "tr", c: "transport input ", modes: ["config-line"] },
        { p: "pa", c: "password ", modes: ["config-line"] },
        // router
        { p: "ne", c: "network ", modes: ["config-router"] },
        { p: "ro", c: "router-id ", modes: ["config-router"] },
        { p: "pa", c: "passive-interface ", modes: ["config-router"] },
        // vlan
        { p: "na", c: "name ", modes: ["config-vlan"] },
        // acl
        { p: "pe", c: "permit ", modes: ["config-acl", "config-ext-acl"] },
        { p: "de", c: "deny ", modes: ["config-acl", "config-ext-acl"] },
        // dhcp
        { p: "ne", c: "network ", modes: ["config-dhcp"] },
        { p: "de", c: "default-router ", modes: ["config-dhcp"] },
        { p: "dn", c: "dns-server ", modes: ["config-dhcp"] },
        // do from config
        { p: "do sh r", c: "do show running-config", modes: ["config", "config-if", "config-line", "config-router", "config-vlan", "config-acl", "config-ext-acl", "config-dhcp"] },
        { p: "do sh ip int", c: "do show ip interface brief", modes: ["config", "config-if"] },
        { p: "do sh vl", c: "do show vlan brief", modes: ["config", "config-if"] },
        { p: "do sh ip ro", c: "do show ip route", modes: ["config", "config-if"] },
        { p: "do wr", c: "do write memory", modes: ["config", "config-if"] },
        { p: "do pi", c: "do ping ", modes: ["config", "config-if"] },
      ];

      const mode = currentState?.mode || "";
      const candidates = allCompletions.filter(c =>
        c.modes.some(m => mode === m || (m === "config" && mode.startsWith("config")))
        && partial.startsWith(c.p)
        && partial.length >= c.p.length
        && partial.length <= c.p.length + 4
      );

      if (candidates.length > 0) {
        // Pick the best match (longest prefix match)
        const best = candidates.sort((a, b) => b.p.length - a.p.length)[0];
        setCurrentInput(best.c);
      }
    }
  }, [handleCommand, cmdHistoryIdx, currentState, currentInput]);

  const toggleTaskComplete = (labId, taskId) => {
    setCompletedTasks(prev => { const key = `${labId}-${taskId}`; return { ...prev, [key]: !prev[key] }; });
  };

  const getLabProgress = (labId) => {
    const labObj = LABS.find(l => l.id === labId);
    if (!labObj) return 0;
    const done = labObj.tasks.filter(t => completedTasks[`${labId}-${t.id}`]).length;
    return Math.round((done / labObj.tasks.length) * 100);
  };

  const filteredLabs = filterCategory === "All" ? LABS : LABS.filter(l => l.category === filterCategory);

  // Theme Toggle Button
  const ThemeToggle = () => (
    <button onClick={() => setDarkMode(p => !p)}
      style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 20, border: `1px solid ${T.border}`, background: T.card, color: T.textMuted, cursor: "pointer", fontSize: 12, fontFamily: "inherit", transition: "all 0.2s" }}
      title={darkMode ? "Switch to Light Theme" : "Switch to Dark Theme"}>
      <span style={{ fontSize: 16 }}>{darkMode ? "☀️" : "🌙"}</span>
      <span>{darkMode ? "Light" : "Dark"}</span>
    </button>
  );

  // CSS keyframes injected once
  const styleTag = `
    @keyframes taskPulse { 0% { box-shadow: 0 0 0 0 rgba(0, 212, 170, 0.4); } 70% { box-shadow: 0 0 0 10px rgba(0, 212, 170, 0); } 100% { box-shadow: 0 0 0 0 rgba(0, 212, 170, 0); } }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
    @keyframes checkBounce { 0% { transform: scale(0); } 50% { transform: scale(1.3); } 100% { transform: scale(1); } }
  `;

  // ─── LAB LIST VIEW ───
  if (showLabList || !selectedLab) {
    return (
      <div style={{ minHeight: "100vh", background: T.bg, color: T.text, fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace", transition: "background 0.3s, color 0.3s" }}>
        <style>{styleTag}</style>
        <div style={{ background: T.headerGrad, borderBottom: `1px solid ${T.borderAccent}`, padding: "24px 32px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16, maxWidth: 1400, margin: "0 auto" }}>
            <div style={{ width: 48, height: 48, background: `linear-gradient(135deg, ${T.accent}, ${T.accentAlt})`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 900, color: darkMode ? "#0a0e17" : "#fff" }}>C</div>
            <div>
              <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: T.accent, letterSpacing: "-0.5px" }}>CCNA 200-301 Lab Simulator</h1>
              <p style={{ margin: 0, fontSize: 12, color: T.textMuted, marginTop: 2 }}>{LABS.length} labs • Cisco IOS CLI • Auto-verify</p>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ fontSize: 11, color: T.textMuted }}>Completed:</span>
              <span style={{ fontSize: 14, color: T.accent, fontWeight: 700 }}>{Object.values(completedTasks).filter(Boolean).length}/{LABS.reduce((a, l) => a + l.tasks.length, 0)}</span>
              <ThemeToggle />
            </div>
          </div>
        </div>

        <div style={{ maxWidth: 1400, margin: "0 auto", padding: "16px 32px" }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {["All", ...CATEGORIES].map(cat => (
              <button key={cat} onClick={() => setFilterCategory(cat)}
                style={{ padding: "6px 16px", borderRadius: 20, border: filterCategory === cat ? `1px solid ${T.accent}` : `1px solid ${T.border}`, background: filterCategory === cat ? T.accentBg : "transparent", color: filterCategory === cat ? T.accent : T.textMuted, cursor: "pointer", fontSize: 12, fontFamily: "inherit", transition: "all 0.2s" }}>
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px 48px", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: 16 }}>
          {filteredLabs.map(l => {
            const progress = getLabProgress(l.id);
            return (
              <div key={l.id} onClick={() => { setSelectedLab(l.id); setShowLabList(false); }}
                style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 12, padding: 20, cursor: "pointer", transition: "all 0.25s", position: "relative", overflow: "hidden" }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent + "55"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.transform = "translateY(0)"; }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: T.border }}>
                  <div style={{ height: "100%", width: `${progress}%`, background: progress === 100 ? T.accent : T.accentAlt, transition: "width 0.3s" }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <span style={{ fontSize: 11, color: T.accentAlt, background: T.catBg, padding: "2px 8px", borderRadius: 6 }}>{l.category}</span>
                  <span style={{ fontSize: 11, color: T.textMuted }}>Lab {l.id}</span>
                </div>
                <h3 style={{ margin: "0 0 8px", fontSize: 15, fontWeight: 600, color: T.text, lineHeight: 1.3 }}>{l.title}</h3>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
                  {l.devices.map(d => (
                    <span key={d.name} style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: d.type === "router" ? T.routerBg : T.switchBg, color: d.type === "router" ? T.routerText : T.switchText, border: `1px solid ${d.type === "router" ? T.routerBorder : T.switchBorder}` }}>
                      {d.type === "router" ? "⟁" : "⊞"} {d.name}
                    </span>
                  ))}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: T.textMuted }}>{l.tasks.length} tasks</span>
                  <span style={{ fontSize: 11, color: progress === 100 ? T.accent : T.textMuted }}>{progress === 100 ? "✓ Complete" : `${progress}%`}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // ─── LAB SIMULATOR VIEW ───
  return (
    <div style={{ display: "flex", height: "100vh", background: T.bg, color: T.text, fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace", overflow: "hidden", transition: "background 0.3s, color 0.3s" }}>
      <style>{styleTag}</style>

      {/* Toast notifications */}
      <div style={{ position: "fixed", top: 16, right: 16, zIndex: 9999, display: "flex", flexDirection: "column", gap: 8 }}>
        {toasts.map((toast, i) => (
          <div key={toast.id}
            style={{ background: T.successBg, border: `1px solid ${T.successBorder}`, borderRadius: 10, padding: "12px 16px", color: T.successText, fontSize: 12, fontFamily: "inherit", maxWidth: 380, animation: "slideIn 0.3s ease-out", boxShadow: "0 4px 20px rgba(0,0,0,0.3)", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 20, animation: "checkBounce 0.5s ease-out" }}>✅</span>
            <span>{toast.text}</span>
          </div>
        ))}
      </div>

      {/* Left Sidebar */}
      <div style={{ width: 400, minWidth: 400, background: T.bgAlt, borderRight: `1px solid ${T.borderAccent}`, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ padding: "14px 16px", borderBottom: `1px solid ${T.border}`, background: T.card }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <button onClick={() => setShowLabList(true)} style={{ background: "none", border: `1px solid ${T.border}`, color: T.textMuted, borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>← Labs</button>
            <span style={{ fontSize: 11, color: T.accentAlt, background: T.catBg, padding: "2px 8px", borderRadius: 6 }}>{lab.category}</span>
            <div style={{ marginLeft: "auto" }}><ThemeToggle /></div>
          </div>
          <h2 style={{ margin: 0, fontSize: 14, fontWeight: 600, color: T.accent }}>Lab {lab.id}: {lab.title}</h2>
          <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ flex: 1, height: 4, background: T.border, borderRadius: 2 }}>
              <div style={{ height: "100%", width: `${getLabProgress(lab.id)}%`, background: T.accent, borderRadius: 2, transition: "width 0.5s ease-out" }} />
            </div>
            <span style={{ fontSize: 11, color: getLabProgress(lab.id) === 100 ? T.accent : T.textMuted, fontWeight: getLabProgress(lab.id) === 100 ? 700 : 400 }}>
              {getLabProgress(lab.id) === 100 ? "✓ DONE" : `${getLabProgress(lab.id)}%`}
            </span>
          </div>
        </div>

        <div style={{ display: "flex", borderBottom: `1px solid ${T.border}` }}>
          {["tasks", "topology", "config"].map(tab => (
            <button key={tab} onClick={() => setSidebarTab(tab)}
              style={{ flex: 1, padding: "10px 8px", background: sidebarTab === tab ? T.card : "transparent", border: "none", borderBottom: sidebarTab === tab ? `2px solid ${T.accent}` : "2px solid transparent", color: sidebarTab === tab ? T.accent : T.textMuted, cursor: "pointer", fontSize: 11, fontFamily: "inherit", textTransform: "uppercase", letterSpacing: 1 }}>
              {tab}
            </button>
          ))}
        </div>

        <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
          {sidebarTab === "tasks" && (
            <div>
              {lab.tasks.map((task, idx) => {
                const key = `${lab.id}-${task.id}`;
                const isComplete = completedTasks[key];
                const isRecent = recentlyCompleted[key];
                const hintVisible = showHint[key];
                return (
                  <div key={task.id} style={{
                    marginBottom: 12, background: isComplete ? T.successBg : T.card, borderRadius: 8,
                    border: `1px solid ${isComplete ? T.successBorder : T.border}`,
                    overflow: "hidden", transition: "all 0.4s ease-out",
                    animation: isRecent ? "taskPulse 1s ease-out 2" : "none",
                  }}>
                    <div style={{ padding: "10px 12px", display: "flex", gap: 8, alignItems: "flex-start" }}>
                      <div style={{
                        width: 22, height: 22, minWidth: 22, borderRadius: 6,
                        border: `2px solid ${isComplete ? T.successBorder : T.textMuted}`,
                        background: isComplete ? T.successBorder : "transparent",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        marginTop: 1, transition: "all 0.3s",
                        cursor: "pointer",
                      }} onClick={() => toggleTaskComplete(lab.id, task.id)}>
                        {isComplete && (
                          <span style={{ color: "#fff", fontSize: 14, fontWeight: 700, animation: isRecent ? "checkBounce 0.5s ease-out" : "none" }}>✓</span>
                        )}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, marginBottom: 3, display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ color: T.accentAlt }}>Task {idx + 1}</span>
                          <span style={{ color: T.textMuted }}>•</span>
                          <span style={{ color: T.switchText }}>{task.device}</span>
                          {isComplete && <span style={{ color: T.successText, fontSize: 10, fontWeight: 600, background: T.successBg, padding: "1px 6px", borderRadius: 4, border: `1px solid ${T.successBorder}` }}>VERIFIED ✓</span>}
                        </div>
                        <div style={{ fontSize: 12, color: isComplete ? T.textMuted : T.text, lineHeight: 1.4, textDecoration: isComplete ? "line-through" : "none" }}>{task.text}</div>
                      </div>
                    </div>
                    <div style={{ padding: "0 12px 8px", display: "flex", gap: 6 }}>
                      <button onClick={() => switchDevice(task.device)}
                        style={{ fontSize: 10, padding: "3px 8px", borderRadius: 4, border: `1px solid ${T.border}`, background: T.bg, color: T.switchText, cursor: "pointer", fontFamily: "inherit" }}>
                        Open {task.device}
                      </button>
                      <button onClick={() => setShowHint(prev => ({ ...prev, [key]: !prev[key] }))}
                        style={{ fontSize: 10, padding: "3px 8px", borderRadius: 4, border: `1px solid ${T.border}`, background: T.bg, color: T.warn, cursor: "pointer", fontFamily: "inherit" }}>
                        {hintVisible ? "Hide" : "Show"} Solution
                      </button>
                    </div>
                    {hintVisible && (
                      <div style={{ padding: "8px 12px", background: T.hintBg, borderTop: `1px solid ${T.border}` }}>
                        <pre style={{ margin: 0, fontSize: 11, color: T.routerText, whiteSpace: "pre-wrap", lineHeight: 1.5 }}>{task.hint}</pre>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {sidebarTab === "topology" && (
            <div>
              {TOPO_IMAGES[lab.id] && (
                <div style={{ background: T.card, borderRadius: 8, border: `1px solid ${T.border}`, padding: 12, marginBottom: 16 }}>
                  <h3 style={{ margin: "0 0 10px", fontSize: 12, color: T.accent, letterSpacing: 1, textTransform: "uppercase" }}>Topology Diagram</h3>
                  <img src={TOPO_IMAGES[lab.id]} alt={`Lab ${lab.id} topology`}
                    style={{ width: "100%", borderRadius: 6, border: `1px solid ${T.border}`, background: "#fff" }} />
                </div>
              )}
              <div style={{ background: T.card, borderRadius: 8, border: `1px solid ${T.border}`, padding: 16 }}>
                <h3 style={{ margin: "0 0 12px", fontSize: 12, color: T.accent, letterSpacing: 1, textTransform: "uppercase" }}>Network Topology (Text)</h3>
                <pre style={{ margin: 0, fontSize: 11, color: T.textDim, lineHeight: 1.6, whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{lab.topology}</pre>
              </div>
              <div style={{ marginTop: 16 }}>
                <h3 style={{ margin: "0 0 8px", fontSize: 12, color: T.accent, letterSpacing: 1, textTransform: "uppercase" }}>Devices</h3>
                {lab.devices.map(d => (
                  <div key={d.name} style={{ background: T.card, borderRadius: 8, border: `1px solid ${T.border}`, padding: 12, marginBottom: 8 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                      <span style={{ fontSize: 14 }}>{d.type === "router" ? "⟁" : "⊞"}</span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: d.type === "router" ? T.routerText : T.switchText }}>{d.name}</span>
                      <span style={{ fontSize: 10, color: T.textMuted }}>({d.type})</span>
                    </div>
                    {d.interfaces && Object.entries(d.interfaces).map(([name, info]) => (
                      <div key={name} style={{ fontSize: 11, color: T.textDim, marginLeft: 22 }}>{name}: {info.ip || "L2"} [{info.status}]</div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}

          {sidebarTab === "config" && currentState && (
            <div>
              <h3 style={{ margin: "0 0 8px", fontSize: 12, color: T.accent, letterSpacing: 1, textTransform: "uppercase" }}>Running Config — {selectedDevice}</h3>
              <div style={{ background: "#0a0e17", borderRadius: 8, border: "1px solid #1e2a3a", padding: 12, maxHeight: "60vh", overflow: "auto" }}>
                <pre style={{ margin: 0, fontSize: 11, color: "#8b9bb4", whiteSpace: "pre-wrap", lineHeight: 1.5, fontFamily: "inherit" }}>
                  {buildRunningConfig(currentState)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right Side - Terminal (ALWAYS DARK) */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", background: "#111820", borderBottom: "1px solid #1e2a3a", padding: "0 8px", minHeight: 40 }}>
          {lab.devices.map(d => (
            <button key={d.name} onClick={() => switchDevice(d.name)}
              style={{ padding: "8px 16px", background: selectedDevice === d.name ? "#0a0e17" : "transparent", border: "none", borderBottom: selectedDevice === d.name ? "2px solid #00d4aa" : "2px solid transparent", color: selectedDevice === d.name ? "#00d4aa" : "#6b7b8d", cursor: "pointer", fontSize: 12, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 10 }}>{d.type === "router" ? "⟁" : "⊞"}</span>{d.name}
            </button>
          ))}
          <div style={{ marginLeft: "auto", display: "flex", gap: 8, paddingRight: 8 }}>
            <button onClick={() => setTerminalHistory([])} style={{ fontSize: 10, padding: "4px 10px", borderRadius: 4, border: "1px solid #1e2a3a", background: "transparent", color: "#6b7b8d", cursor: "pointer", fontFamily: "inherit" }}>Clear</button>
          </div>
        </div>

        <div ref={terminalRef} onClick={() => inputRef.current?.focus()}
          style={{ flex: 1, overflow: "auto", padding: "12px 16px", background: "#0a0e17", cursor: "text" }}>
          {terminalHistory.map((entry, i) => (
            <div key={i} style={{
              color: entry.type === "system" ? "#0891b2" : entry.type === "input" ? "#e0e6ed" : entry.type === "success" ? "#4ade80" : "#8b9bb4",
              fontSize: 13, lineHeight: 1.5, whiteSpace: "pre-wrap", fontFamily: "inherit"
            }}>{entry.text}</div>
          ))}
          {currentState && (
            <div style={{ display: "flex", alignItems: "center", fontSize: 13, lineHeight: 1.5 }}>
              <span style={{ color: "#00d4aa", whiteSpace: "pre" }}>{getPrompt(currentState)} </span>
              <input ref={inputRef} value={currentInput} onChange={e => setCurrentInput(e.target.value)} onKeyDown={handleKeyDown}
                style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "#e0e6ed", fontSize: 13, fontFamily: "inherit", caretColor: "#00d4aa", padding: 0, margin: 0 }}
                spellCheck={false} autoComplete="off" autoFocus />
            </div>
          )}
        </div>

        <div style={{ background: "#111820", borderTop: "1px solid #1e2a3a", padding: "6px 16px", display: "flex", alignItems: "center", gap: 16, fontSize: 10, color: "#6b7b8d" }}>
          <span>Mode: <span style={{ color: "#00d4aa" }}>{currentState?.mode || "—"}</span></span>
          {currentState?.currentInterface && <span>Int: <span style={{ color: "#f59e0b" }}>{currentState.currentInterface}</span></span>}
          {currentState?.currentVlan && <span>VLAN: <span style={{ color: "#f59e0b" }}>{currentState.currentVlan}</span></span>}
          {currentState?.currentRouter && <span>Router: <span style={{ color: "#f59e0b" }}>{currentState.currentRouter}</span></span>}
          {currentState?.currentAcl && <span>ACL: <span style={{ color: "#f59e0b" }}>{currentState.currentAcl}</span></span>}
          {currentState?.currentDhcpPool && <span>DHCP: <span style={{ color: "#f59e0b" }}>{currentState.currentDhcpPool}</span></span>}
          {currentState?.currentLine && <span>Line: <span style={{ color: "#f59e0b" }}>{currentState.currentLine}</span></span>}
          <span style={{ marginLeft: "auto" }}>Tab: autocomplete • ↑↓: history • do: exec from config</span>
        </div>
      </div>
    </div>
  );
}
